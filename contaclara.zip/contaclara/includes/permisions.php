<?php
session_start();
 if($_SESSION['user_authorized']!=true || $_SESSION['cambio']=='1')
 { 
  header("Location: ../../index.php"); 
 }
/* else
 {
 	if($_SESSION['cambio']=='1')
 	{
      header("Location: ../../index.php");
 	}
 }*/




?>