       <section class="sidebar">
         
         
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu">
              <!-- <li>
                <a href="../examples/captura.php"><i class="fa fa-camera"></i> <span>Captura de imágenes</span></a>
              </li> -->
           <?php
     
            if($_SESSION['cambio']==0)
            {
              if($_SESSION['perfil']=='Administrador')
              {
           ?>   
               
                      <!--    <li class="treeview">
                 
                        <a href="#">
                        <i class="fa fa-male"></i>
                        <span>Admin Options</span>
                        <i class="fa fa-angle-left pull-right"></i>
                        </a>

                        <ul class="treeview-menu" style="display: none;">

                             <li>
                            <a href="../examples/dashboard.php"><i class="fa fa-table"></i> <span>Dashboard</span></a>
                          </li>

                          <li>
                            <a href="../examples/usuarios.php"><i class="fa fa-user-plus"></i> <span>Ingreso de usuarios</span></a>
                          </li>
                           <li>
                            <a href="../examples/compras.php"><i class="fa fa-credit-card"></i> <span>Compras</span></a>
                          </li>

                           <li>
                            <a href="../examples/revenues.php"><i class="fa fa-money"></i> <span>Revenues</span></a>
                          </li>

                        

                          <li>
                               <a href="../examples/sucursales.php"><i class="fa fa-building"></i> <span>Crear Sucursales</span></a>
                          </li>

                           <li>
                               <a href="../examples/carriers.php"><i class="fa fa-truck"></i> <span>Crear Carriers</span></a>
                          </li>
                            <li>
                              <a href="../examples/rever_pedidos.php"><i class="fa fa-undo"></i> <span>Reversar Pedidos</span></a>
                            </li>


                                                        

                        </ul> 

               </li> -->

           <!--      <li class="treeview">
                 
                        <a href="#">
                        <i class="fa fa-table"></i>
                        <span>Reportes</span>
                        <i class="fa fa-angle-left pull-right"></i>
                        </a>

                        <ul class="treeview-menu" style="display: none;">

                             <li>
                            <a href="../examples/historic_clientes.php"><i class="fa fa-files-o"></i> <span>Histórico de clientes</span></a>
                          </li>

                          <li>
                            <a href="../examples/usuarios.php"><i class="fa fa-files-o"></i> <span>Diario de ventas</span></a>
                          </li>
                           <li>
                            <a href="../examples/compras.php"><i class="fa fa-files-o"></i> <span>Histórico de Compras </span></a>
                          </li>

                           <li>
                            <a href="../examples/revenues.php"><i class="fa fa-files-o"></i> <span>Análisis de ganancias</span></a>
                          </li>

                        

                          <li>
                               <a href="../examples/sucursales.php"><i class="fa fa-files-o"></i> <span>Facturación</span></a>
                          </li>

                           <li>
                               <a href="../examples/carriers.php"><i class="fa fa-files-o"></i> <span>Cuentas Por Cobrar</span></a>
                          </li>
                            <li>
                              <a href="../examples/rever_pedidos.php"><i class="fa fa-files-o"></i> <span>Recaudo</span></a>
                            </li>
                            

                                                        

                        </ul> 

               </li> -->

           <?php
              }
             }
           ?>   
             <!--   <li>
                <a href="../examples/cambio_password.php"><i class="fa fa-key"></i> <span>Cambio de contraseña</span></a>
              </li> -->
          <?php
               if($_SESSION['cambio']==0)
            {
               if($_SESSION['perfil']=='Manager')
               {
           ?> 
                   
                  <!--    <li>
                            <a href="../examples/dashboard.php"><i class="fa fa-table"></i> <span>Dashboard</span></a>
                          </li> -->

                <?php
                 }
                ?>
                          <li>
                            <a href="../examples/usuarios.php"><i class="fa fa-user-plus"></i> <span>Ingreso de usuarios</span></a>
                          </li>   

                         <li>
                            <a href="../examples/clientes.php"><i class="fa fa-users"></i> <span>Clientes</span></a>
                          </li>
               
             <!--   <li>
                <a href="../examples/calculadora.php"><i class="fa fa-calculator"></i> <span>Calculadora</span></a>
              </li>
              <li>
                <a href="../examples/wishlist.php"><i class="fa fa-file"></i> <span>Crear cotización</span></a>
              </li>
                  <li>
                <a href="../examples/pedidos.php"><i class="fa fa-file-text"></i> <span>Generar Pedido</span></a>
              </li>
             
                <li>
                <a href="../examples/p_sucur.php"><i class="fa fa-building"></i> <span>Seguimiento</span></a>
              </li>
               
              
              
                  <li>
                <a href="../examples/facturado.php"><i class="fa fa-money"></i> <span>Recaudos</span></a>
              </li>

                  <li>
                <a href="../examples/imp_facturas.php"><i class="fa fa-print"></i> <span>Imprimir Facturas</span></a>
              </li>           -->

                <?php
             }
           ?>   
               <li>
                <a href="../examples/gestcompras.php"><i class="fa fa-shopping-cart"></i> <span>Compras</span></a>
              </li>
              <li>
                <a href="../../includes/destroy.php"><i class="fa fa-money"></i> <span>Ventas</span></a>
              </li>
              <li>
                <a href="../../includes/destroy.php"><i class="fa fa-folder-open-o"></i> <span>Gastos</span></a>
              </li>
               <li>
                <a href="../../includes/destroy.php"><i class="fa fa-sign-out"></i> <span>Salir</span></a>
              </li>
         

            <!--   <li class="treeview">
                <a href="#">
                  <i class="fa fa-file-text-o"></i>
                  <span>Exámenes</span>
                  <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="pages/UI/general.html"><i class="fa fa-circle-o text-red"></i> Examen 1</a></li>
                  <li><a href="pages/UI/icons.html"><i class="fa fa-circle-o text-yellow"></i> Examen 2</a></li>
                  <li><a href="pages/UI/buttons.html"><i class="fa fa-circle-o text-blue"></i> Examen 3</a></li>
                
                </ul>
              </li> -->
               


              
            </ul>
          </section>