<?php
 session_start();
  include('_include/configuration.php');
  include('_classes/conectar.php');
  include('_classes/crud.php');

  $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
  

     $crud->setConsulta("select * from usuario where nick = '$_GET[uid1]' and password = '$_GET[uid2]' and estado = 'Activo'");
     $datos1=$crud->seleccionar($con->getConection());
     
      if($crud->getTuplas()>0)
      {
          if($datos1[0]['cambio_password']==0)
          {   
            $_SESSION['user_authorized'] = true;
            $_SESSION['nom'] = $datos1[0]['nombre'];;
            $_SESSION['apel'] = $datos1[0]['apellido'];
            $_SESSION['password'] = $datos1[0]['password'];
            $_SESSION['usuario'] = $datos1[0]['nick'];
            $_SESSION['rol'] = $datos1[0]['perfil'];
            $_SESSION['id'] = $datos1[0]['id'];
            $_SESSION['cambio'] = $datos1[0]['cambio_password'];
            //$_SESSION['sucursal'] = $datos1[0]['sucursal'];
            $_SESSION['perfil'] = $datos1[0]['perfil'];
          
           ?>
         
            <div id="error_p" class="alert alert-success alert-dismissible" >
                  <button type="button" class="close" id="close_error" onclick="cerrar()">&times;</button>
           Bienvenido(a) <?php echo $_SESSION['nom']?> Ingresa a la aplicación           
           </div>
            
          <?php
          }
          else
          {
            $_SESSION['user_authorized'] = true;
            $_SESSION['nom'] = $datos1[0]['nombre'];;
            $_SESSION['apel'] = $datos1[0]['apellido'];
            $_SESSION['password'] = $datos1[0]['password'];
            $_SESSION['usuario'] = $datos1[0]['nick'];
            $_SESSION['rol'] = $datos1[0]['perfil'];
            $_SESSION['id'] = $datos1[0]['id'];
            $_SESSION['cambio'] = $datos1[0]['cambio_password'];
              
           ?>
               <div id="error_p" class="alert alert-warning alert-dismissible" >
                  <button type="button" class="close" id="close_error" onclick="cerrar()">&times;</button>
           Bienvenido(a) <?php echo $_SESSION['nom']?><br/>  Debes cambiar tu password               
           </div>
            
          <?php
          }
      }
      else
      {
      

        ?>
   
    <div id="error_p" class="alert alert-danger alert-dismissable" >
                  <button type="button" class="close" id="close_error" onclick="cerrar()">&times;</button>
          Verifique su usuario y contraseña.                
      </div>

        <?php
      }



  
?>