<? 
mail("jailtonyanesromero@gmail.com","asuntillo","Este es el cuerpo del mensaje");

?>