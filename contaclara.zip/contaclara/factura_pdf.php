<?php
include('_classes/crud.php');
include('_include/configuration.php');
include('_classes/conectar.php');


 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
  $crud_consec = new Crud();

     $crud_consec->setConsulta("SELECT consecutivo FROM cot_n_f WHERE cot_id = '$_GET[refe]'");
                                            $datos_consec = $crud_consec->seleccionar($con->getConection());

    $consecutivo  = $datos_consec[0]['consecutivo'];                                       








    $crud->setConsulta("SELECT
    `cotizacion`.`id`
    , `cliente`.`cip_ruc`
    , `cliente`.`nombre`
    , `cliente`.`apellido`
    , `cliente`.`direccion`
    , `cliente`.`telefono1`
    , `cliente`.`email`
    , `cotizacion`.`fecha_creacion`
    ,cliente.cip_ruc
    ,cliente.id as id_cli
FROM
    `cotizacion`
    INNER JOIN `cliente` 
        ON (`cotizacion`.`cliente_id` = `cliente`.`id`) where cotizacion.id = '$_GET[refe]'");
                                            $datos1 = $crud->seleccionar($con->getConection());


$date = date_create($datos1[0]['fecha_creacion']);

$fecha = date_format($date, 'd-m-Y');
//fin---------                                            


//datos de la sucursal
 $crud3 = new Crud();
//datos de la sucursal
 $crud3 = new Crud();
 $crud3->setConsulta("SELECT
  
     `sucursal`.`nombre`
    , `sucursal`.`provincia_id`
    , `sucursal`.`distrito_id`
    , `sucursal`.`direcion`
    , `sucursal`.`email`
    , `sucursal`.`telefono`
    ,(SELECT nombre FROM provincia WHERE id = (SELECT
  
   
    `sucursal`.`provincia_id`

    
   
FROM
    `cotizacion`
    INNER JOIN `usuario` 
        ON (`cotizacion`.`creada_por` = `usuario`.`id`)

    INNER JOIN `sucursal` 
            ON (`usuario`.`sucursal` = `sucursal`.`id`)
            
            
             WHERE cotizacion.id = '$_GET[refe]') ) AS prov_nombre
  ,(SELECT nombre FROM distrito WHERE id = (SELECT
  
   
    `sucursal`.`distrito_id`

    
   
FROM
    `cotizacion`
    INNER JOIN `usuario` 
        ON (`cotizacion`.`creada_por` = `usuario`.`id`)

    INNER JOIN `sucursal` 
            ON (`usuario`.`sucursal` = `sucursal`.`id`)
            
            
             WHERE cotizacion.id = '$_GET[refe]') ) AS distri_nombre            
    
   
FROM
    `cotizacion`
    INNER JOIN `usuario` 
        ON (`cotizacion`.`creada_por` = `usuario`.`id`)

    INNER JOIN `sucursal` 
            ON (`usuario`.`sucursal` = `sucursal`.`id`)
            
            
             WHERE cotizacion.id = '$_GET[refe]'");

    $datos3 = $crud3->seleccionar($con->getConection());
require_once('dompdf/dompdf_config.inc.php');
$export='<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Cotizacion</title>
</head>
<style type="text/css">
 
  

* {
  margin:  0;
  padding: 0;
}


  .arriba{
  	
  	padding:3px;
  	background-color: #000;
  	color: #FFF;
  	text-align:center;
  	font-size:24px;
  }

  .importante
  {
  	 	padding:3px;
  
  	color: #000;
  	text-align:center;
  	font-size:15px;
  	margin-top:30px;
  }
  .distancia
  {
  		padding:3px;
  
  	color: #000;
  	text-align:center;
  	font-size:13px;
  }

  #datos_emp
  {
  	margin-left:250px;
  	margin-top:-80px;
  }
  #imagen
  {
  	margin-top:5px;
  	margin-left:40px;
  	witdh:160px;
  	height:100px;
  }
  #encabezado{
    margin-left:30px;
  }

  #encabezado tr td{

     padding:5px;
  }
  
  #encabezado tr td p,#encabezado tr td h3,{
     padding-left:20px;  
  }

  #info_cli
  {
  	margin-left:7px;
  	margin-top:10px;
  	width:680px;
  }

  #productos
  {
  	margin-top:15px;
  	width:800px;
  	margin-left:7px;
  }

  #terminos
  {
  		margin-top:80px;
  	width:800px;
  	margin-left:7px;
  }

  #terminos tr td
  {
  	font-size:12px;
  }
  #autorizacion
  {
  	margin-top:50px;
  	margin-left:100px;
  }
  .borde
  {
     border-bottom: 1px solid #000;
     border-right: 1px solid #000;
     border-top: 1px solid #000;
     border-left: 1px solid #000;

  }
  .borde_lateral
  {
      border-right: 1px solid #000;
      border-left: 1px solid #000;
  }
   .borde_lateral_abajo
  {
      border-right: 1px solid #000;
      border-left: 1px solid #000;
      border-bottom: 1px solid #000;
       
  }
</style>
<body>
	<h1 class="arriba">FACTURA DE VENTA</h1>
	
	<table id="encabezado">
    <tr>
       <td><img  src="images/SMI_LOGO2.png" alt="logo" witdh="220" height="130"></td>
       <td>  <h3>
           SM IMPORTS
        </h3>
        <p>
            RUC. 8-800-513 DV.86

        </p>
        <p>
           '.$datos3[0]['prov_nombre'].', '.$datos3[0]['distri_nombre'].'<br/>'.$datos3[0]['direcion'].'
        </p>
   
        <p>'.$datos3[0]['telefono'].' </p>
        <p>'.$datos3[0]['email'].'</p></td>
        <td>
            <p style="padding-left:20px;font-weight:bold;font-size:20px">FACT Nº:</p> <p style="color:red;font-weight:bold;padding-left:25px;font-size:29px" >'.$consecutivo.'</p>
        </td>
       
    </tr>
	</table>
    <table id="linea2" >
     <tr>
      <td align="center">
        _____________________________________________________________________________________________________________
      </td>
     </tr>
 
  </table>
	<table id="info_cli">
    <tr>
      <td align="right">&nbsp;<span style="font-weight:bold">SMI-CLIENTE:</span></td>
      <td>&nbsp;&nbsp;'.$datos1[0]['id_cli'].'</td>
      <td rowspan="5"><span style="font-weight:bold">&nbsp;&nbsp;&nbsp;FECHA: </span>'.$fecha.'<br/> <span style="font-weight:bold">CPI/RUC: </span>'.$datos1[0]['cip_ruc'].'<br/> <span style="font-weight:bold">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;REF: </span>'.$_GET['refe'].' </td>
    </tr>
    <tr>
    <td align="right">&nbsp;<span style="font-weight:bold">NOMBRE:</span></td>
      <td>&nbsp;&nbsp;'.$datos1[0]['nombre'].' '.$datos1[0]['apellido'].'</td>
    </tr>
    <tr>
        <td align="right">&nbsp;<span style="font-weight:bold">DIRECCION:</span></td>
      <td>&nbsp;&nbsp;'.$datos1[0]['direccion'].'</td>
    </tr>
    <tr>
          <td align="right">&nbsp;<span style="font-weight:bold">TELÉFONO:</span></td>
      <td>&nbsp;&nbsp;'.$datos1[0]['telefono1'].'</td>
    </tr>
    <tr>
          <td align="right">&nbsp;<span style="font-weight:bold">E-MAIL:</span></td>
      <td>&nbsp;&nbsp;'.$datos1[0]['email'].'</td>
    </tr>
	</table>
	<table  id="productos"  cellspacing="0" cellpadding="0" border="0" >
	  <tr>
           <td class="borde" align="center"><span style="font-weight:bold">CANT.</span></td>
           <td class="borde" align="center"><span style="font-weight:bold">DESCRIPCIÓN</span></td>
           <td class="borde" align="center"><span style="font-weight:bold">P. UNIT.</span></td>
           
           <td class="borde" align="center"><span style="font-weight:bold">P. WEB</span></td>
           <td class="borde" align="center"><span style="font-weight:bold">FLETE</span></td>
           <td class="borde" align="center"><span style="font-weight:bold">TOTAL</span></td>
          
	  </tr>';
$crud2 = new Crud();	 
 $crud2->setConsulta("SELECT * from items where cotizacion_id = '$_GET[refe]'");
                                             $datos2 = $crud2->seleccionar($con->getConection());
                                             $i=0;$subt=0;$itbms=0;
                                             while ($i<sizeof($datos2))
                                             {   

   $export=$export.'<tr >
           <td class="borde_lateral" align="center">'.$datos2[$i]['cantidad'].'</td>
           <td class="borde_lateral" align="left">&nbsp;'.$datos2[$i]['descripcion'].'&nbsp;</td>
              <td class="borde_lateral" align="right">&nbsp;'.number_format($datos2[$i]['precio_articulo'],2,'.',',').'&nbsp;</td>
           <td class="borde_lateral" align="right">&nbsp;'.number_format($datos2[$i]['precio_web'],2,'.',',').'&nbsp;</td>
           <td class="borde_lateral" align="right">&nbsp;'.number_format($datos2[$i]['segundo_flete'],2,'.',',').'&nbsp;</td>
           <td class="borde_lateral" align="right">&nbsp;'.number_format($datos2[$i]['total'],2,'.',',').'&nbsp;</td>
	  </tr>';
	  	
	                                           $subt=$subt+$datos2[$i]['total']; 
                                             $itbms = $itbms+$datos2[$i]['segundo_flete'];
                                             $i++;
                                             }
       
	     $export=$export.'<tr>
           <td class="borde_lateral_abajo" align="center">&nbsp;</td>
           <td class="borde_lateral_abajo" align="left">&nbsp;&nbsp;</td>
           <td class="borde_lateral_abajo" align="right">&nbsp;</td>
           <td class="borde_lateral_abajo" align="right">&nbsp;</td>
            <td class="borde_lateral_abajo" align="right">&nbsp;</td>
             <td class="borde_lateral_abajo" align="right">&nbsp;</td>
    </tr>

    <tr>
           <td  align="right"></td>
           <td  align="right"></td>
            <td  align="right"></td>
          <td align="right"></td>
          <td class="borde_lateral_abajo" align="right"><span style="font-weight:bold">SUB-TOTAL:</span></td>
          <td class="borde_lateral_abajo" align="right"> '.number_format($subt,2,'.',',') .'&nbsp;</td>
         
       
          
	  </tr>
	    <tr>
           <td  align="right"></td>
           <td  align="right"></td>
           <td  align="right"></td>
          <td align="right"></td>
          <td class="borde_lateral_abajo" align="right"><span style="font-weight:bold">ITBMS:</span></td>
          <td  class="borde_lateral_abajo" align="right">'.number_format(($itbms*0.07),2,'.',',').'&nbsp;</td>
         
   
          
	  </tr>
      <tr>
           <td  align="right"></td>
           <td  align="right"></td>
           <td  align="right"></td>
          <td align="right"></td>
          <td class="borde_lateral_abajo"  align="right"><span style="font-weight:bold">TOTAL:</span></td>
          <td class="borde_lateral_abajo" align="right"> '.number_format($subt+($itbms*0.07),2,'.',',').'&nbsp;</td>
         
   
          
    </tr>





	</table>

    <table id="terminos">
      <tr>
       <td align="justify">
         <span style="font-weight:bold"> Condiciones de venta:</span>
         <br/>

1. El Cliente acepta que una vez realizada la compra y aceptado el pago, ya no es posible realizar cambios o anular el pedido.
 <br/>
2. Después de entregado el pedido NO se aceptan devoluciones de ningún tipo. Cualquier excepción a este lineamiento debe ser autorizado por el Gerente.
 <br/>
3. Es de conocimiento del cliente, que el importe total calculado en el pedido es un valor aproximado. Este valor podrá sufrir variaciones en cuanto se obtenga el peso y dimensiones reales de los artículos incluidos en este pedido.
 <br/>
     </td>
      </tr>
  </table>

  <table id="autorizacion" >
     <tr>
      <td align="center">
        __________________________________
      </td>
      <td align="center">
        __________________________________
      </td>
      

     </tr>
  
     <tr>
      <td align="center">
        <span style="font-weight:bold">AUTORIZADO POR:</span>

      </td>
       <td align="center">
        <span style="font-weight:bold">RECIBIDO POR:</span>

      </td>
     </tr>
  </table>
<br/>
<br/>
<br/>
<br/>
	<h1 class="importante"> ESTA COTIZACIÓN TIENE UNA VALIDEZ DE TRES DÍAS A PARTIR DE LA FECHA DE EXPEDICIÓN DE LA MISMA </h1>
	<h2 class="distancia"> ¡Tus compras a un click de ti con SMI! </h2>

</body>
</html>';
$export=utf8_decode($export);
$dompdf = new DOMPDF();
$dompdf->load_html(utf8_encode($export));
ini_set("memory_limit","500M");
$dompdf->render();
$dompdf->stream("factura".$fecha.'_SMI_'.$datos1[0]['id_cli'].".pdf");
?>