<?php
   include('../_include/configuration.php');
  $connection=mysql_connect($server,$user,$password);
  mysql_select_db($dbname);
   mysql_query("SET NAMES 'utf8'");

	 $query = "
SELECT fecha_creacion,SUM(precio_web) AS precio_web,SUM(flete) AS flete,direccion,provincia,distrito,telefono1,telefono2,email,cip_ruc,cotizacion,smi,nombre,apellido,item_id,con_ab_it,total_cotizacion,abonado,
SUM(tot_precio_item) AS tot_precio_item,descripcion,SUM(total_abonado_item) AS total_abonado_item,SUM(flete_smi * 0.07) AS flete_smi,porcentaje_ab
,(SELECT  COUNT(item_id)AS cantiad  FROM saldos
WHERE cotizacion = '$_GET[ocul]')AS cantidad  FROM saldos
WHERE cotizacion = '$_GET[ocul]'

		";
$result = mysql_query($query,$connection);
$row = mysql_fetch_array($result);
$date = date_create($row['fecha_creacion']);



 //hacer las comparaciones de los fletes
                                                            
                                                 $query_comp=" SELECT segundo_flete,
  (precio_web+flete_smi+flete_smi*0.07) AS p_flete,(precio_web+COALESCE(`segundo_flete`,0)+COALESCE(`segundo_flete`,0)*0.07) AS s_flete
   FROM items WHERE items.`cotizacion_id` = $_GET[ocul] ";
                                              $result= mysql_query($query_comp,$connection);   
                                              if($result)
                                              {
                                                  $difer =0;
                                                   while($row_comp = mysql_fetch_array($result))
                                                            {
                                                                if($row_comp['segundo_flete'] != 0)
                                                                { 
                                                                  $difer = $difer + ($row_comp['s_flete'] - $row_comp['p_flete']);
                                                                }
                                                                 
                                                            }
                                              }
                                              else
                                              {
                                              	echo mysql_error();
                                              }
                                                           
                                                           //fin hacer las comparaciones de los fletes








$devengo=$row['precio_web']+$row['flete']+$row['flete']*0.07;
  $deduc=  $row['abonado']+$row['total_abonado_item']; 

mysql_close($connection);

header("Content-Type: text/html;charset=utf-8");
echo '<?xml version="1.0" encoding="iso-8859-1"?>
<user>
<id>'.$row['smi'].'</id>
<cip_ruc>'.$row['cip_ruc'].'</cip_ruc>
<nombre>'.$row['nombre'].'</nombre>
<apellido>'.$row['apellido'].'</apellido>
<direccion>'.$row['direccion'].'</direccion>
<provincia>'.$row['provincia'].'</provincia>
<distrito>'.$row['distrito'].'</distrito>
<telefono1>'.$row['telefono1'].'</telefono1>
<telefono2>'.$row['telefono2'].'</telefono2>
<email>'.$row['email'].'</email>
<fecha_creacion>'.date_format($date, 'd-m-Y').'</fecha_creacion>
<cot_id>'.$row['cotizacion'].'</cot_id>
<contador>'.$row['cantidad'].'</contador>
<total>'.$row['tot_precio_item'].'</total>
<f_smi>'.number_format($row['flete_smi'],2,".",",").'</f_smi>
<t_pagar>'.number_format(($row['tot_precio_item']+$row['flete_smi']),2,".",",").'</t_pagar>
<sp>'.number_format($devengo-$deduc+$difer,2,".",",").'</sp>

</user>';
?>