 <?php
session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>


 <table class="table table-bordered table-striped table-condensed" id="table_id">
                                       <thead>
                                          <tr>
                                             <th>REF.</th>
                                             <th>SUCURSAL</th>
                                            
                                             <th>SERVICIO</th>
                                             <th>FECHA PEDIDO</th>
                                             <th>CLIENTE</th>
                                             <th>DESCRIPCION</th>
                                             <th>PRECIO WEB</th>
                                             <th>FLETE SMI</th>
                                             <th>TOTAL</th>
                                             <th>ABONO</th>
                                        
                                          </tr>   
                                       </thead>
                                
                                       <tbody>
                           
                                       <?php
                                         $crud->setConsulta("SELECT
    cotizacion.id AS referencia,    
    `sucursal`.`nombre` AS `sucursal`
    , `items`.`tipo_servicio`
    , `cotizacion`.`fecha_pedido`
    , `cliente`.`id` AS `cliente`
    , `cliente`.`nombre`
    , `cliente`.`apellido`
   
    , `items`.`descripcion`
    , `items`.`weblink`
    , `items`.`precio_web`
    , `items`.`flete_smi`
    , `items`.`total`
    , `cotizacion`.`porcentaje_ab`
    ,items.id as item

FROM
    `items`
    INNER JOIN `cotizacion` 
        ON (`items`.`cotizacion_id` = `cotizacion`.`id`)
    INNER JOIN `usuario` 
        ON (`usuario`.`id` = `cotizacion`.`creada_por`)
    INNER JOIN `cliente` 
        ON (`cotizacion`.`cliente_id` = `cliente`.`id`)
    INNER JOIN `sucursal` 
        ON (`sucursal`.`id` = `usuario`.`sucursal`)
WHERE items.`estado` IS NULL and cotizacion.pedido_por = '$_SESSION[id]' ORDER BY sucursal ASC, fecha_pedido ASC");
                     $datos1 = $crud->seleccionar($con->getConection());
                       $i=0;
                       while ($i<sizeof($datos1))
                       {                        
                                       
                              $abono = $datos1[$i]['total'] * $datos1[$i]['porcentaje_ab'] / 100;

                                       ?>
                                        <tr>
                                          <td><a style="cursor:pointer" onclick="javascript:modal_ap(<?php echo $datos1[$i]['item']  ?>)"><?php echo $datos1[$i]['referencia'] ?></a> </td>
                                         <td><!-- <a style="cursor:pointer" data-target="#itmesadd" data-toggle="modal" data-param="<?php echo $datos1[$i]['item']  ?>"><?php echo $datos1[$i]['sucursal'] ?></a> -->
                                                    <?php echo $datos1[$i]['sucursal'] ?>
                                         </td>
                                       
                                         <td><?php echo $datos1[$i]['tipo_servicio'] ?> </td>
                                         <td><?php echo $datos1[$i]['fecha_pedido'] ?> </td>
                                         <td><?php echo 'SMI-'.$datos1[$i]['cliente'].' '.$datos1[$i]['nombre'].' '.$datos1[$i]['apellido'] ?> </td>
                                         <td align="left"><?php echo $datos1[$i]['descripcion']?> </td>
                                         <td align="right"><?php echo number_format($datos1[$i]['precio_web'],2,'.',',') ?> </td>
                                         <td align="right"><?php echo number_format($datos1[$i]['flete_smi'],2,'.',',') ?> </td>
                                         <td align="right"><?php echo number_format($datos1[$i]['total'],2,'.',',') ?> </td>
                                         <td align="right"><?php echo number_format($abono,2,'.',',') ?> </td>
                               
                                        </tr> 
                      <?php
                            $i++;
                        }
                     ?>

                                       </tbody>
                                    </table>  