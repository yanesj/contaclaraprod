 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>


 <table id="pedi" class="display">
                                          <thead>
                                            <tr>
                                              <th>FECHA</th>
                                       
                                              <th>REF</th>
                                       
                                              <th>DESCRIP</th>
                                              <th>ESTADO</th>
                                              <th>TOT USD</th>
                                              
                                             
                                              
                                             
                                              
                                              
                                            </tr>
                                          </thead>
                                          <tbody id="cuerpo">
                                         
                                               <?php
                                             $crud->setConsulta("SELECT
    `items`.`descripcion`
    , `items`.`cotizacion_id`
    , `items`.`estado`
       , (`items`.`total` + (items.`flete_smi` * 0.07)) AS total
    ,cotizacion.`fecha_pedido`
FROM
    `items`
    INNER JOIN `cotizacion` 
        ON (`items`.`cotizacion_id` = `cotizacion`.`id`)
    INNER JOIN `cliente` 
        ON (`cliente`.`id` = `cotizacion`.`cliente_id`) WHERE cliente.id='$_GET[uid]' AND cotizacion.estado='PEDIDO' ");
                                             $datos1 = $crud->seleccionar($con->getConection());
                                             $i=0;
                                             while ($i<sizeof($datos1))
                                             {   
                                            
                                               $date = date_create($datos1[$i]['fecha_pedido']);
                                            ?>


                                                                  <tr>
                                                                     <td><?php echo date_format($date, 'd-m-Y');  ?></td>
                                                                    <td><?php echo $datos1[$i]['cotizacion_id'] ?></td>
                                                                    <td><?php echo $datos1[$i]['descripcion'] ?></td>
                                                                    <td><?php if($datos1[$i]['estado'] ==''){echo 'NO COMPRADO';}else{echo $datos1[$i]['estado'];} ?></td>
                                                                     <td align="right"><?php echo '$'.number_format($datos1[$i]['total'],2,".",",") ?></td>
                                                                
                                                                  
                                                                  
                                                                  </tr>

                                           <?php
                                               $i++;
                                            }
                                           ?>                       
                                     </tbody>
                                        </table> 

<?php
  $con->desconectar();
?>
