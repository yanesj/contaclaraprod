<?php
  session_start();
  include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
  $mensaje = "Estado cambiado con exito.";
  $fecha = date('Y-m-d');
  $crud->moneda_dec($_POST['neto_pg']);
  $total = $crud->getValor();
  $crud->moneda_dec($_POST['c_abonar']);
  $abono = $crud->getValor(); 

 
 $porcentaje_ab = '$_POST[porcentaje]';
  if($_POST['f_pago']=='ACUERDO PAGO')
  {
     $abono = 0;
     $porcentaje_ab =0;
  }

  $f = explode("/", $_POST['f_cobro']);
  $fecha_cobro = $f[2].'/'.$f[1].'/'.$f[0];
  
  $crud->update("update cotizacion set estado = 'PEDIDO',fecha_pedido ='$fecha',pedido_por ='$_SESSION[id]', total = '$total',abonado='$abono', forma_pago ='$_POST[f_pago]', fecha_cobro ='$fecha_cobro', porcentaje_ab ='$porcentaje_ab' where id = '$_POST[condition]'",$mensaje,$con->getConection());



 $con->desconectar();


?>



