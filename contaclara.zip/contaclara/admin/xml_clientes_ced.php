<?php
   include('../_include/configuration.php');
  $connection=mysql_connect($server,$user,$password);
  mysql_select_db($dbname);
   mysql_query("SET NAMES 'utf8'");

 $query = "select * from cliente  where cedunit= '$_GET[ocul]'";
$result = mysql_query($query,$connection);
$row = mysql_fetch_array($result);

mysql_close($connection);

header("Content-Type: text/html;charset=utf-8");
echo '<?xml version="1.0" encoding="iso-8859-1"?>
<user>
<id>'.$row['cedunit'].'</id>
<tipodoc>'.$row['tipodoc'].'</tipodoc>
<papel>'.$row['papel'].'</papel>
<sapel>'.$row['sapel'].'</sapel>
<pnombre>'.$row['pnombre'].'</pnombre>
<snombre>'.$row['snombre'].'</snombre>
<rsocial>'.$row['rsocial'].'</rsocial>
<direccion>'.$row['direccion'].'</direccion>
</user>';
?>