 <?php
 session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>


 <table id="table_id" class="display">
                                          <thead>
                                            <tr>
                                              <th>CÉDULA/NIT</th>
                                       
                                              <th>APELLIDOS</th>
                                              <th>NOMBRES</th>
                                              <th>RAZÓN SOCIAL</th>
                                              
                                             
                                              
                                              <th>Acciones</th>
                                              
                                              
                                            </tr>
                                          </thead>
                                          <tbody id="cuerpo">
                                            <?php

      $crud->setConsulta("SELECT cedunit,papel,sapel,pnombre,snombre,rsocial FROM cliente ORDER BY papel,sapel,pnombre,snombre,rsocial   "); 

                                             $datos1 = $crud->seleccionar($con->getConection());
                                             $i=0;
                                             while ($i<sizeof($datos1))
                                             {   
                                            ?>
                          <tr>
                            <td><a style="cursor:pointer" ><?php echo $datos1[$i]['cedunit'] ?></a></td>
                        
                            <td><?php echo $datos1[$i]['papel'].' '.$datos1[$i]['sapel'] ?></td>
                            <td><?php echo $datos1[$i]['pnombre'].' '.$datos1[$i]['snombre'] ?></td>
                            <td><?php echo $datos1[$i]['rsocial']  ?></td>
                        
                          
                            <td align="center"><a style="cursor:pointer" class="fa fa-pencil" title="Edit" onclick="edit_user(<?php echo $datos1[$i]['cedunit'] ?>)"></a> &nbsp;<a style="cursor:pointer" class="fa fa-trash" title="Remove" onclick="delete_user(<?php echo $datos1[$i]['cedunit'] ?>)"></a>
                            </td>
                          </tr>
  <?php
    $i++;
   }
  ?>


<?php
 $con->desconectar();


?>
                                          </tbody>
                                        </table> 