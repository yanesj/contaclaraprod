 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>


 <table id="table_id" class="display">
                                          <thead>
                                            <tr>
                                              <th>SMI</th>
                                              <th>Nombre</th>
                                            
                                              <th>Fecha Acuerdo de Pago</th>
                                              <th>Días vencidos</th>
                                              <th>Cantidad acordada</th>
                                              
                                          
                                              
                                              
                                            </tr>
                                          </thead>
                                          <tbody id="cuerpo">
                                            <?php
                                             $crud->setConsulta("SELECT
    `cliente`.`nombre`
    , `cliente`.`apellido`
    , `cotizacion`.`fecha_cobro`
    , `cotizacion`.`total`
    , `cotizacion`.`porcentaje_ab`
    , `usuario`.`sucursal`
    ,cotizacion.`forma_pago`
    ,cliente.id
FROM
    `cliente`
    INNER JOIN `cotizacion` 
        ON (`cliente`.`id` = `cotizacion`.`cliente_id`)
    INNER JOIN `usuario` 
        ON (`cotizacion`.`creada_por` = `usuario`.`id`)
        
        WHERE cotizacion.`forma_pago`= 'ACUERDO PAGO'");
                                             $datos1 = $crud->seleccionar($con->getConection());
                                             $i=0;
                                             while ($i<sizeof($datos1))
                                             { 

                                                $cant_pactada = $datos1[$i]['total'] * $datos1[$i]['porcentaje_ab'] /100; 

                                                /*Dias vencidos*/
                                                $fecha_cob= $datos1[$i]['fecha_cobro']." 00:00:00";
$segundos=  strtotime('now') - strtotime($fecha_cob) ;

$diferencia_dias=intval($segundos/60/60/24);





                                            
                                           if($diferencia_dias < 0)
                                           {
                                             $color = "color:orange;font-weight:bold";
                                           }
                                           else
                                           {
                                              if($diferencia_dias == 0)
                                             {
                                               $color = "color:green;font-weight:bold";
                                             }
                                             else
                                             {
                                               $color = "color:red;font-weight:bold";
                                             }
                                           }


                                            ?>
                          <tr>
                            <td><?php echo 'SMI-'.$datos1[$i]['id'] ?></td>
                            <td><?php echo $datos1[$i]['nombre'].' '.$datos1[$i]['apellido'] ?></td>
                            <td><?php echo $datos1[$i]['fecha_cobro'] ?></td>
                            <td><span style="<?php echo $color ?>"> <?php echo $diferencia_dias ?> </span></td>
                              <td class="text-right"><?php echo '$'.number_format($cant_pactada,2,',','.')?></td>
                           
                          </tr>
  <?php
    $i++;
   }
  ?>


<?php
 $con->desconectar();


?>
                                          </tbody>
                                        </table> 