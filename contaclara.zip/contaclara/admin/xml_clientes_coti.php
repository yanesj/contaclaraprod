<?php

   include('../_include/configuration.php');

  $connection=mysql_connect($server,$user,$password);

  mysql_select_db($dbname);

   mysql_query("SET NAMES 'utf8'");



   $query = " SELECT `cliente`.`id` AS cliente,`cliente`.`nombre`,`cliente`.`apellido`
        ,cliente.`direccion`
        ,cliente.`provincia`
        ,cliente.`distrito`
        ,cliente.`telefono1`
        ,cliente.`telefono2`
        ,cliente.`email`
        ,cliente.`cip_ruc`
        ,cotizacion.id as cot_id
        ,cotizacion.`fecha_creacion`
        ,COUNT(cotizacion.id)AS cantidad,
      SUM(items.`total`)AS total
        ,SUM(items.`flete_smi`) AS f_smi
         FROM cliente JOIN cotizacion ON (cliente.id= cotizacion.`cliente_id`)
         JOIN items ON (items.`cotizacion_id`=cotizacion.id)
WHERE cotizacion.id= '$_GET[ocul]' AND cotizacion.`estado`= 'COTIZADO'


    ";

$result = mysql_query($query,$connection);

$row = mysql_fetch_array($result);

$date = date_create($row['fecha_creacion']);



mysql_close($connection);



header("Content-Type: text/html;charset=utf-8");

echo '<?xml version="1.0" encoding="iso-8859-1"?>

<user>

<id>'.$row['cliente'].'</id>

<cip_ruc>'.$row['cip_ruc'].'</cip_ruc>

<nombre>'.$row['nombre'].'</nombre>

<apellido>'.$row['apellido'].'</apellido>

<direccion>'.$row['direccion'].'</direccion>

<provincia>'.$row['provincia'].'</provincia>

<distrito>'.$row['distrito'].'</distrito>

<telefono1>'.$row['telefono1'].'</telefono1>

<telefono2>'.$row['telefono2'].'</telefono2>

<email>'.$row['email'].'</email>

<fecha_creacion>'.date_format($date, 'd-m-Y').'</fecha_creacion>

<cot_id>'.$row['cot_id'].'</cot_id>

<contador>'.$row['cantidad'].'</contador>

<total>'.$row['total'].'</total>

<f_smi>'.number_format($row['f_smi']*0.07,2,".",",").'</f_smi>

<t_pagar>'.number_format(($row['total']+($row['f_smi']*0.07)  ),2,".",",").'</t_pagar>

<sp>'.number_format(($row['sp']),2,".",",").'</sp>



</user>';

?>  