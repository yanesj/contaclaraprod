 <?php
session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>


 <table id="table_id" class="display">
                                       <thead>
                                          <tr>
                                            
                                             <th>SUCURSAL</th>
                                             <th>TIPO SERV</th>
                                             <th>REF</th>
                                             <th>ITEM</th>
                                            <!-- <th>P. WEB</th>
                                             <th>FLETE</th> !-->
                                             <th>E.PTY PRICE</th>
                                             <!--<th>COSTO TOTAL</th>
                                             <th>E. PTY SHIPPING</th>
                                             <th>E. PTY PRICE</th>
                                             <th>R. PTY SHIPPING</th> !-->
                                             <th>R. PTY PRICE</th>
                                             <th>E. REVENUE </th>
                                             <th>E.% REVENUE</th>
                                             <th>R REVENUE</th>
                                             <th>R.% REVENUE</th>
                                           
                                          </tr>   
                                       </thead>
                                        <tbody>
  <?php                                     
              $crud->setConsulta("SELECT sucursal.`nombre`,items.`tipo_servicio`,items.`cotizacion_id`,items.`descripcion`,
items.precio_web,items.flete_smi,COALESCE(segundo_flete,NULL,0)AS segundo_flete,(compras.`costo`+compras.`real_shipping`) AS realpty,(items.total-items.precio_web) as erev,items.total as tot_it 
FROM
   `cotizacion`
    INNER JOIN `usuario` 
        ON (`cotizacion`.`creada_por` = `usuario`.`id`)
    INNER JOIN `sucursal` 
        ON (`usuario`.`sucursal` = `sucursal`.`id`)
    INNER JOIN `items` 
        ON (`items`.`cotizacion_id` = `cotizacion`.`id`)
    INNER JOIN `compras` 
        ON (`compras`.`item_id` = `items`.`id`) WHERE items.`peso_item` <=2 ORDER BY items.`cotizacion_id` ASC ");
                     $datos1 = $crud->seleccionar($con->getConection());
                       $i=0;
                       while ($i<sizeof($datos1))
                       {                             

                           
                            if($datos1[$i]['segundo_flete']==0)
                            {
                               $pre_prim_flete = $datos1[$i]['precio_web'] + $datos1[$i]['flete_smi'] ;
                              
                               $total = $pre_prim_flete ;
                            }
                            else
                            {
                                
                                $pre_prim_flete =  $datos1[$i]['precio_web'] + $datos1[$i]['segundo_flete'];
                              
                                $total = $pre_prim_flete;
                                $parte1 = $datos1[$i]['tot_it']-$datos1[$i]['realpty'];
                            }   
?>
                                        <tr>
                                         
                                         <td><?php echo $datos1[$i]['nombre'] ?></td>
                                        
                                       
                                         <td><?php echo $datos1[$i]['tipo_servicio'] ?></td>
                                         <td><?php echo $datos1[$i]['cotizacion_id'] ?></td>
                                         <td><?php echo $datos1[$i]['descripcion'] ?></td>
                                         <td><?php echo '$'.number_format($total,2,'.',',') ?></td>
                                        <td><?php echo '$'.number_format($datos1[$i]['realpty'],2,'.',',') ?></td>
                                         <td><?php echo '$'.number_format($datos1[$i]['erev'],2,'.',',') ?></td>
                                         <td><?php echo number_format($datos1[$i]['erev']/$total*100) ?></td>
                                         <td><?php echo '$'.number_format($datos1[$i]['tot_it']-$datos1[$i]['realpty'],2,'.',',') ?></td>
                                          <td><?php echo number_format($parte1/$datos1[$i]['realpty']*100) ?></td>
                                       

                                        </tr>
                       <?php
                           $i++;

                         }  
                       ?>

                                       </tbody>
                                    </table>  