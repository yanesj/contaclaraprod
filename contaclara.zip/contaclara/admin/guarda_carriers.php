<?php
 session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();


  $fecha = date('Y-m-d');
  
  $fnaci = explode("/", $_POST['f_nac']);

  $f_entra = $fnaci[2]."/".$fnaci[1]."/".$fnaci[0];

	 
  $crud->moneda_dec($_POST['precio_carga']);
  $precio_carga = $crud->getValor(); 

    $crud->moneda_dec($_POST['precio_r']);
  $precio_r = $crud->getValor(); 

   if($_POST['idocul']=='')
	 { 
		   
      $array[0] = "'$_POST[nombre]','$precio_carga','$precio_r'";
		  $campos = "nombre,precio_tarifa,precio_real";
		  $tabla = "carrier";
		  $mensaje = "Carrier Guardado con exito.";
		  $crud->insertar($array,$campos,$tabla,$con->getConection(),$mensaje); 
     }
    else
    {
         

         $crud->update("update carrier set nombre = '$_POST[nombre]',precio_tarifa = '$precio_carga', precio_real = '$precio_r' where id = '$_POST[idocul]'",'Carrier actualizado exitosamente.',$con->getConection());  
    } 


 $con->desconectar();


?>

