 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>



                                         
                                               <?php
                                             $crud->setConsulta("        
SELECT

 SUM(`items`.`total`
  +
   flete_smi * 0.07) AS total
FROM
    `items`
    INNER JOIN `cotizacion` 
        ON (`items`.`cotizacion_id` = `cotizacion`.`id`)
    INNER JOIN `cliente` 
        ON (`cliente`.`id` = `cotizacion`.`cliente_id`)
        
         WHERE cliente.id='$_GET[uid]' AND cotizacion.estado='PEDIDO' ");
                                             $datos1 = $crud->seleccionar($con->getConection());


                                             echo "Total Pedido $: ".number_format($datos1[0]['total'],2,".",",");


 


 $con->desconectar();                                         