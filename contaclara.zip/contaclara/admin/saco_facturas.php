<?php
session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>











 <table class="table table-bordered table-striped table-condensed" id="table_id">
                                       <thead>
                                          <tr>
                                             <th class="text-center">REFERENCIA</th>
                                              <th class="text-center">RUC/CIP</th>
                                              <th class="text-center">CLIENTE</th>
                                              <th class="text-center">TOTAL FACTURA</th>
                                  
                                             <th class="text-center">IMPRIMIR FACTURA</th>
                                        
                                          </tr>   
                                       </thead>
                                
                                       <tbody>
                           
                                       <?php
                                         $crud->setConsulta("   SELECT cotizacion_id, SUM(peso_item) AS peso_it,COUNT(items.id) AS id,cliente.id AS smi_cli,cliente.apellido,cliente.`nombre`,cliente.`cip_ruc`
,SUM(precio_web)AS p_web ,SUM(segundo_flete) AS segundo_flete FROM items
     JOIN cotizacion ON(items.`cotizacion_id`=cotizacion.id)
JOIN cliente ON (cotizacion.`cliente_id`=cliente.`id`)    
      GROUP BY items.`cotizacion_id` HAVING peso_it =0 ");
                     $datos1 = $crud->seleccionar($con->getConection());
                       $i=0;$total=0;
                 
                       while ($i<sizeof($datos1))
                       {                        
                                       
                               $total = $datos1[$i]['p_web'] + $datos1[$i]['segundo_flete'] + ($datos1[$i]['segundo_flete']*0.07);


                                       ?>
                                        <tr>
                                          <td class="text-right"><a style="cursor:pointer"><?php echo  $datos1[$i]['cotizacion_id']  ?></a> </td>
                                          <td><a style="cursor:pointer"><?php echo  $datos1[$i]['cip_ruc']  ?></a> </td>
                                          <td><a style="cursor:pointer"><?php echo 'SMI-'.$datos1[$i]['smi_cli'].' '.$datos1[$i]['nombre'].' '.$datos1[$i]['apellido'] ?></a> </td>
                                          <td class="text-right"><a style="cursor:pointer"><?php echo '$'.number_format($total,2,',','.')   ?></a> </td>
                                         <td class="text-center"><!-- <a style="cursor:pointer" data-target="#itmesadd" data-toggle="modal" data-param="<?php echo $datos1[$i]['item']  ?>"><?php echo $datos1[$i]['sucursal'] ?></a> -->
                                                    <a class="fa fa-print" onclick="imprime(<?php echo $datos1[$i]['cotizacion_id'] ?>)" title="Print" style="cursor:pointer"></a>
                                         </td>
                                       
                                       
                                        </tr> 
                      <?php
                            $i++;
                        }
                     ?>

                                       </tbody>
                                    </table>  