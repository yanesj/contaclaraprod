<?php
 session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crudp = new Crud();
  $crud2 = new Crud();
  $crud3 = new Crud();
  $crud4 = new Crud();
  $crud_aver = new Crud();
  $crud = new Crud();



/*saco la cotizacion*/
  $crud4->setConsulta(" SELECT items.`cotizacion_id` FROM items WHERE items.id = '$_POST[item]' ");
                                             $datos_it = $crud4->seleccionar($con->getConection());
                                             $i=0;$consecutivo=0;
                                             while ($i<sizeof($datos_it))
                                             {   
                                               $coti =  $datos_it[$i]['cotizacion_id'];
                                             
                                              $i++;
                                             }



$crud->update("update items set  estado = 'ENTREGADO',peso_item = 0 where id = $_POST[item]",'Item entregado exitosamente.',$con->getConection());  



/*evaluo si puedo entregar*/
  $crud_aver->setConsulta(" SELECT COUNT(id) AS cantidad FROM items WHERE items.`cotizacion_id` = '$coti' AND estado <> 'ENTREGADO' ");
                                             $datos_aver = $crud_aver->seleccionar($con->getConection());
                                             $i=0;$consecutivo=0;$canti=0;
                                             while ($i<sizeof($datos_aver))
                                             {   
                                               $canti =  $datos_aver[$i]['cantidad'];
                                             
                                              $i++;
                                             }

if($canti == 0)
{
	/*Preliminares*/




/*Saco el inicial de cada  sucursal*/
  $crud3->setConsulta(" SELECT id as id_fisc,num_ini   FROM num_fisc WHERE suc_id = '$_SESSION[sucursal]' ");
                                             $datos2 = $crud3->seleccionar($con->getConection());
                                             $i=0;$consecutivo=0;
                                             while ($i<sizeof($datos2))
                                             {   
                                               $num_ini =  $datos2[$i]['num_ini'];
                                               $fiscal = $datos2[$i]['id_fisc'];
                                              $i++;
                                             }

/*Saco cuantos Consecutivos tiene la sucursal en mención*/
  $crud2->setConsulta("SELECT COALESCE(count(consecutivo),0) AS consecutivo FROM cot_n_f WHERE suc_id = '$_SESSION[sucursal]' ");
                                             $datos1 = $crud2->seleccionar($con->getConection());
                                             $i=0;$consecutivo=0;$consec=0;
                                             while ($i<sizeof($datos1))
                                             {   
                                               $consecutivo =  $datos1[$i]['consecutivo'] +1;
                                              $i++;
                                             }

                                            $consec=$num_ini+$consecutivo;


 /*Inserto en la tabla de muchos a muchos*/  
         
        $conectar = mysql_connect($server,$user,$password);
        mysql_select_db($dbname);

        $query = "insert into cot_n_f (cot_id,num_fiscal_id,consecutivo,suc_id)values('$coti','$fiscal','$consec','$_SESSION[sucursal]') ";  
        $result = mysql_query($query,$conectar);

        if($result)
        {
        	
        } 
        else
        {
        	echo mysql_error();
        }
   
}




	                                    






// $con->desconectar();


?>

