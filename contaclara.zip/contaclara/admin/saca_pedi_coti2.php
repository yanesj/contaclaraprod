 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>


 <table id="pedi2" class="display">
                                          <thead>
                                            <tr>
                                              <th>FECHA</th>
                                       
                                              <th>REF</th>
                                       
                                              <th>DESCRIP</th>
                                              <th>ESTADO</th>
                                              <th>TOT USD</th>
                                              
                                            </tr>
                                          </thead>
                                          <tbody id="cuerpo">
                                         
                                               <?php
                                             $crud->setConsulta("SELECT
    `items`.`descripcion`
    , `items`.`cotizacion_id`
    , `items`.`estado`
    , `items`.`total` 
    ,cotizacion.`fecha_creacion`
    ,flete_smi
FROM
    `items`
    INNER JOIN `cotizacion` 
        ON (`items`.`cotizacion_id` = `cotizacion`.`id`)
    INNER JOIN `cliente` 
        ON (`cliente`.`id` = `cotizacion`.`cliente_id`)
        
         WHERE cliente.id='$_GET[uid]' AND cotizacion.estado='COTIZADO' ");
                                             $datos1 = $crud->seleccionar($con->getConection());
                                             $i=0;
                                             while ($i<sizeof($datos1))
                                             {   
                                                $date = date_create($datos1[$i]['fecha_creacion']);
                                            ?>

                                                                  <tr>
                                                                     <td><?php  echo date_format($date, 'd-m-Y');  ?></td>
                                                                    <td><?php echo 'REF '.$datos1[$i]['cotizacion_id'] ?></td>
                                                                    <td><?php echo $datos1[$i]['descripcion'] ?></td>
                                                                    <td>COTIZADO</td>
                                                                     <td align="right"><?php echo '$'.number_format(($datos1[$i]['total']+$datos1[$i]['flete_smi']*0.07),2,".",",") ?></td>
                                                                
                                                                  
                                                                  
                                                                  </tr>

                                           <?php
                                               $i++;
                                            }
                                           ?>                       
                                     </tbody>
                                        </table> 
<?php
 $con->desconectar();
?>
