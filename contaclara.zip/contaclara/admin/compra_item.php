<?php
  session_start();
  include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
  $crud2 = new Crud();
   $crud3 = new Crud();


      $crud2->update("UPDATE items SET estado = 'EN TRANSITO', segundo_link = '$_POST[slink]', peso_item= '2'  WHERE id = '$_POST[item]'"," ",$con->getConection());


      
       $crud4= new Crud();
       $crud4->moneda_dec($_POST['costo']);
       $costo= $crud4->getValor();
       $crud5= new Crud();
       $crud5->moneda_dec($_POST['real_ship']);
       $shipping= $crud5->getValor();

 
      $array[0] = "'$_POST[carrier]','$costo','$shipping','$_POST[item]'";
      $campos = "carrier,costo,real_shipping,item_id";
      $tabla = "compras";
      $mensaje ='Item Pasado a Compra.';
      $crud->insertar($array,$campos,$tabla,$con->getConection(),$mensaje); 
       

    /* cambio el estado del item en  cotizacion */
     $crud->setConsulta("SELECT cotizacion_id   FROM items where id = '$_POST[item]'");
    $datos1 = $crud->seleccionar($con->getConection()); 
    $coti = $datos1[0]['cotizacion_id'];  
$crud->update("UPDATE cotizacion  SET estado_items = 'EN TRANSITO'  WHERE id = '$coti'  "," ",$con->getConection());



 $con->desconectar();


?>



