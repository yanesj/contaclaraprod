<?php
  session_start();
  include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
 
  $crud2 = new Crud();

  $crud2->moneda_dec($_POST['flete_smi']);

  $flete_smi = $crud2->getValor();
   $crud2->moneda_dec($_POST['total']);

  $total = $crud2->getValor();


      $crud2->update("UPDATE items SET estado = 'EN ALMACEN', peso_r = '$_POST[peso]', tipo_peso = '$_POST[tipo_peso]', segundo_flete = '$flete_smi',total = '$total'
        ,peso_item = '1'
        WHERE id = $_POST[item]","Item descargado con exito.",$con->getConection());
  



 
    
       

       


 $con->desconectar();


?>



