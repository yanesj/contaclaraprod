<?php
 session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();


//  $pieces = explode('.', $_POST['suc']);
  //$sucursal = $pieces[0]; 
  $fecha = date('Y-m-d');
  //     $crud->moneda_dec($_POST['monto']);
     //  $total =$crud->getValor();


  //forma de pago
   if($_POST['forma_p']=='ACH')
   {
       $observaciones = $_POST['ob'];
       $url=$_SESSION['nom_ar'];
   }
   else
   {
     $url='';
     if($_POST['forma_p']=='CHEQUE')
     {
         $observaciones = $_POST['ob2'];
     } 
     else
     {
         $observaciones = '';
     }
   }
  //--     

	 
/*		  $array[0] = "'$_POST[id_ocul]','$fecha','$_POST[refe]','$_POST[forma_p]','$url','$total','$_SESSION[id]','$_SESSION[sucursal]','$observaciones','$_POST[]'";
		  $campos = "smi_cliente,fecha_abono,referencia,forma_pago,monto,creado_por,sucursal,observaciones,item_id";
		  $tabla = "abono";
		  $mensaje = "Abono Guardado con exito.";
		  $crud->insertar($array,$campos,$tabla,$con->getConection(),$mensaje); 
 */
 

$i=0;
$acum =0;
$fecha = date('Y-m-d');
/*while(isset($_POST['abo'.$i]))
{
 
    $crud->moneda_dec($_POST['abo'.$i]);
       $total =$crud->getValor();
       $acum = $acum + $total;*/
        $array = array();
        $array = null;
         $array1 = array();
        $array1 = null;

    $array[0] = $array[0]."('".$_POST['id_ocul']."','".$fecha."','".$_POST['refe']."','".$_POST['forma_p']."','".$_SESSION['id']."','".$_SESSION['sucursal']."','".$observaciones."','".$_POST['cheque']."','".$_POST['banco']."'),";
       
   
/*  $i++;
}*/
     
  /*   $crud->moneda_dec($_POST['sp']);
       $sp =$crud->getValor();

    if($acum>$sp)
    {
      echo'Verifique las canditades digitadas.';
    }
    else
    {*/

      $array[0] = trim($array[0],",");
      $campos = "smi_cliente,fecha_abono,referencia,forma_pago,creado_por,sucursal,observaciones,cheque,banco";
      $tabla = "abono";
      $mensaje = "Abono Guardado con exito.";
      $crud->insertar3($array,$campos,$tabla,$con->getConection());
        
      if($crud->getMensajeExito()=='ok')
      {
         $i=0;
         while(isset($_POST['abo'.$i]))
         {
           $ult = $crud->getLastid();
           
           $crud->moneda_dec($_POST['abo'.$i]);
           $abono_trans =$crud->getValor();  
           $array1[0]= $array1[0]."('".$ult."','".$_POST['item'.$i]."','".$abono_trans."'),";
           $i++;
         }
          
           $array1[0] = trim($array1[0],",");

           $crud3 = new Crud();
           $campos3 = "abono_id,item_id,monto";
           $tabla3 = "abono_item";
           $crud3->insertar3($array1,$campos3,$tabla3,$con->getConection());
           $mensaje= $crud3->getMensajeExito();        
           echo $mensaje;
      }
      else
      {
        echo 'Error en el proceso.';
      }   
   


   /* }*/

 $con->desconectar();


?>



