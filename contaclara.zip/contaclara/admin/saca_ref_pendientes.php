 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>
                                    

      <div class="col-md-12">       
                                            <div class="form-group">
                                                <label for="provincia">Seleccione Referencia:</label>
                                                <br/>
                                               <select   class="selectpicker form-group"  data-live-search="true" id="cliente" name="cliente">
                                                   <option value="Escoja opción" slected="selected">Escoja opción</option> 

                                                            <?php
                                                         $crud->setConsulta("SELECT direccion,provincia,distrito,telefono1,telefono2,email,cip_ruc,cotizacion,smi,nombre,apellido,item_id,con_ab_it,total_cotizacion
,abonado,tot_precio_item, SUM(total_abonado_item)AS total_abonado_item
,SUM(flete_smi)AS flete_smi,SUM(itbms)AS itbms
 FROM saldos_agrupados_items GROUP BY cotizacion");
                                                         $datos1 = $crud->seleccionar($con->getConection());
                                                         $i=0;
                                                         while ($i<sizeof($datos1))
                                                         {   
                                                     
                                                          /*  if(number_format($datos1[$i]['s_pendiente'],2,'.',',')>0)
                                                             {*/
                                                     ?> 
                                                    <option value="<?php echo $datos1[$i]['cotizacion']?>"><?php echo 'Ref_nro: '.$datos1[$i]['cotizacion'].'**'.'SMI-'.$datos1[$i]['smi'].'**'.$datos1[$i]['nombre'].' '.$datos1[$i]['apellido'].'** USD '.number_format($devengo-$deduc,2,'.',',') ?></option>    
                                                     <?php
                                                             /*}  */

                                                           $i++;
                                                          $con->desconectar();
                                                         } 
                                                     ?>


                                               </select>
                                            </div> 
                                   </div> 




                                       


                                        