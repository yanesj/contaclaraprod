<?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
  $crud3 = new Crud();
  $crud4 = new Crud();
  $crud5 = new Crud();

  $fecha = date('Y-m-d');
  $cadena = "cotizacion_id = '$_POST[refe]'";
  $crud3->eliminar("items",$con->getConection(),"$cadena","");
  $crud4->update("update cotizacion set fecha_creacion = '$fecha' where id = '$_POST[refe]'","no",$con->getConection());


     $i=1;
     $valores ='';
     while($i<= $_POST['contador'])
     {
       $tipo_serv=$_POST['tipo_serv_'.$i];
       $descrip= $_POST['ocul_descr_'.$i];
       $weblink= $_POST['ocul_link_'.$i];
        $crud->moneda_dec($_POST['precio_'.$i]);
        $precio= $crud->getValor();

       $cantidad= $_POST['cantidad_'.$i];
       $crud->moneda_dec($_POST['costo_ship_'.$i]);
       $shipping=$crud->getValor();
       $peso= $_POST['peso_'.$i];
       $state=$_POST['state_tax_'.$i];
       $crud->moneda_dec($_POST['pa_'.$i]);
       $precio_web=$crud->getValor();
       $crud->moneda_dec($_POST['flete_'.$i]);
       $flete = $crud->getValor();
       $crud->moneda_dec($_POST['subtotal_'.$i]);
       $total =$crud->getValor();
       $cotizacion_id = $_POST['refe'];
       $tipo_ar = $_POST['ocul_tipo_ar_'.$i];
       $proced = $_POST['ocul_proced_'.$i];
       $peso_item= '3';

          //quitar las "," de los numeros para guardarlos en la base de datos.

        



       $valores= $valores."('".$tipo_serv."','".$descrip."','".$weblink."','".$precio."','".$cantidad."','".$shipping."','".$precio_web."','".$flete."','".$total."','".$peso."','".$state."','".$cotizacion_id."','".$tipo_ar."','".$proced."','".$peso_item."'),";     
       
       $i++;
     }	 
    $valores =trim($valores,",");


		      $array[0] = $valores;
    		  $campos = "tipo_servicio,descripcion,weblink,precio_articulo,cantidad,shipping,precio_web,flete_smi,total,peso,state_tax,cotizacion_id,tipo_ar,procedencia,peso_item";
    		  $tabla = "items";
    		  $mensaje = "Datos guardados con exito.";
    		  $crud->insertar2($array,$campos,$tabla,$con->getConection(),$mensaje); 

            $crud5->update("UPDATE items
 SET primer_abono = TRUNCATE(((total+ (flete_smi*0.07) ) * (SELECT TRUNCATE(porcentaje_ab/100,2) FROM cotizacion WHERE id = '$_POST[refe]') ),2)",'ok',$con->getConection());





 $con->desconectar();


?>



