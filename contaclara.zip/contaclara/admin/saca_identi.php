 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>



<?php
 $crud->setConsulta("SELECT id,nombre,apellido from cliente where id = '$_GET[uid]' ");
 $datos1 = $crud->seleccionar($con->getConection());
                                           
  echo "Historial de ".$datos1[0]['nombre'].' '.$datos1[0]['apellido'].' SMI-'.$datos1[0]['id'];

  ?>


<?php
 $con->desconectar();


?>
                                         