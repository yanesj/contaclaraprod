 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>
                                              <option value="0" slected="selected">Escoja opción</option>
                                            <?php
                                             $crud->setConsulta("SELECT items.id, descripcion,cliente.`nombre`,cliente.`apellido` FROM items 
JOIN cotizacion ON (cotizacion.id = items.`cotizacion_id`) 
JOIN cliente  ON (cliente.id = cotizacion.`cliente_id`)
WHERE cotizacion.id = '$_GET[uid]'
 ORDER BY items.id ASC");
                                             $datos1 = $crud->seleccionar($con->getConection());
                                             $i=0;
                                             while ($i<sizeof($datos1))
                                             {   
                                            ?>
                                                <option value="<?php echo $datos1[$i]['id'] ?>"><?php echo $datos1[$i]['descripcion'] ?></option>
  

                                            <?php
                                              $i++;
                                             }
                                            ?>


<?php
 $con->desconectar();


?>
                                        