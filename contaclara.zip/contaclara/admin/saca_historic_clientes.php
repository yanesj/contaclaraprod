 <?php
session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
  $crud_items = new Crud();
?>











 <table class="table table-bordered table-striped table-condensed" id="table_id">
                                       <thead>
                                          <tr>
                                             <th>SMI</th>
                                             <th>NOMBRE</th>
                                            
                                             <th>APELLIDO</th>
                                             <th>EDAD</th>
                                             
                                             <th>TIPO</th>
                                             <th>SUCURSAL</th>
                                             <th># PEDIDOS</th>
                                             <th># ITEMS</th>
                                             <th>ABONADO</th>
                                             <th>ADEUDADO</th>
                                             <th>FECHA DE ALTA</th>
                                      
                                          </tr>   
                                       </thead>
                                
                                       <tbody>
                           
                                       <?php
                                         $crud->setConsulta("SELECT cliente.id,cliente.nombre,
cliente.apellido,COUNT(cotizacion.id) AS pedido
,TIMESTAMPDIFF(YEAR, cliente.fecha_nacimiento, CURDATE()) AS edad

     ,DATE_FORMAT(cliente.fecha_creacion,'%d-%m-%Y') AS fecha_creacion,sucursal.nombre as sucursal,
CASE tipo_cli
WHEN 1 THEN 'Estándar'
WHEN 2 THEN 'Comercial'
END AS tipo_cliente

 FROM cliente
JOIN cotizacion ON (cliente.id = cotizacion.cliente_id)
JOIN usuario ON(usuario.id = cliente.creado_por)
JOIN sucursal ON(usuario.sucursal = sucursal.id)

WHERE cotizacion.estado = 'PEDIDO'
GROUP BY cliente.id ");
                     $datos1 = $crud->seleccionar($con->getConection());
                       $i=0;
                     
                       while ($i<sizeof($datos1))
                       {                        
                       

                         $crud_items = new Crud();
                        //Cantidad de items 
                        $crud_items->setConsulta("SELECT
COUNT(items.id) AS cant_item
FROM
    `items`
    INNER JOIN `cotizacion` 
        ON (`items`.`cotizacion_id` = `cotizacion`.`id`)
    INNER JOIN `cliente` 
        ON (`cliente`.`id` = `cotizacion`.`cliente_id`)
        
      WHERE cotizacion.`estado`= 'PEDIDO' AND cliente.id = ".$datos1[$i]['id']);
                        $cant_items = $crud_items->seleccionar($con->getConection());
                  
                       
                        $cant_items[0]['cant_item'];
                        //

                         
                                       ?>
                                        <tr>
                                          <td><?php echo 'SMI - '.$datos1[$i]['id']?></td>
                                         <td><?php echo $datos1[$i]['nombre']?>  </td>
                                       
                                         <td><?php echo $datos1[$i]['apellido']?> </td>
                                         <td align="right"><?php echo $datos1[$i]['edad']?></td>
                                         <td><?php echo $datos1[$i]['tipo_cliente']?> </td>

                                         
                                         <td><?php echo $datos1[$i]['sucursal']?> </td>
                                         <td align="right"><?php echo $datos1[$i]['pedido']?> </td>
                                         <td align="right"><?php echo $cant_items[0]['cant_item']?> </td>
                                         <td align="right"><?php echo '0'?> </td>
                                         <td align="right"><?php echo '0'?></td>
                                         <td align="right"><?php echo $datos1[$i]['fecha_creacion']?></td>
                                    



                                    
                                        </tr> 
                      <?php
                            $i++;
                        }
                     ?>

                                       </tbody>
                                    </table>  