<?php
 session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
  $crud2 = new Crud();


	 if($_POST['idocul']=='')
	 { 
		   
      $array[0] = "'$_POST[cip_ruc]','$_POST[dv]','$_POST[apellido1]','$_POST[apellido2]','$_POST[nombre1]','$_POST[nombre2]','$_POST[direccion]','$_POST[rsocial]','$_POST[coddep]','$_POST[codmun]','$_POST[codpais]','$_POST[tipo_contribu]','$_POST[calidadcontri]','$_POST[comentarios]'";
		  $campos = "cedunit,dv,papel,sapel,pnombre,snombre,direccion,rsocial,coddepart,codmun,codpais,gcontri,calidadcontri,notaevalcontri";
		  $tabla = "cliente";
		  $mensaje = "Cliente Guardado con exito.";
		  $crud->insertar($array,$campos,$tabla,$con->getConection(),$mensaje); 
     }
    else
    {
         

         $crud->update("update cliente set cedunit = '$_POST[cip_ruc]' ,dv = '$_POST[dv]',papel = '$_POST[apellido1]',sapel ='$_POST[apellido2]',pnombre = '$_POST[nombre1]',snombre = '$_POST[nombre2]',direccion = '$_POST[direccion]',rsocial = '$_POST[rsocial]',coddepart = '$_POST[coddep]',codmun = '$_POST[codmun]',codpais = '$_POST[codpais]',gcontri = '$_POST[tipo_contribu]',calidadcontri = '$_POST[calidadcontri]',notaevalcontri = '$_POST[comentarios]'  where cedunit = '$_POST[idocul]'",'Cliente actualizado exitosamente.',$con->getConection());  
          $i=1;
          while($i<=7)  
            { 
              $valor = $_POST['reti'.$i];
              $crud2->update("UPDATE cliente_retencion SET valor = $valor WHERE retencion_id= $i AND cliente_id = '$_POST[idocul]' "," ",$con->getConection());
              $i++;
            }
    } 


 $con->desconectar();


?>
                          
