 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>



                                         
                                               <?php
                                             $crud->setConsulta("        
SELECT direccion,provincia,distrito,telefono1,telefono2,email,cip_ruc,cotizacion,smi,nombre,apellido,item_id,con_ab_it,total_cotizacion,(abonado) AS abonado,
SUM(tot_precio_item) AS tot_precio_item,descripcion,SUM(total_abonado_item) AS total_abonado_item,SUM(flete_smi * 0.07) AS flete_smi,porcentaje_ab  FROM saldos


WHERE smi = '$_GET[uid]' GROUP BY cotizacion
 ");
                                             $datos1 = $crud->seleccionar($con->getConection());


                                               $i=0;
                                               $abonado =0;
                                               $adeudado =0;
                                               $precio_item= 0;
                                               $abon_item =0;
                                             while ($i<sizeof($datos1))
                                             { 
                                          $abonado= $abonado +$datos1[$i]['abonado'];
                                          $abon_item = $abon_item + $datos1[$i]['total_abonado_item'];
                                          $precio_item = $precio_item + $datos1[$i]['tot_precio_item'] + $datos1[$i]['flete_smi'] ;  


                                               $i++;
                                             }

?>
                                
                                 <p><?php echo  "Total Abonado $: ".number_format($abonado,2,".",",").' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; '."Total Adeudado $: ".number_format($precio_item-$abonado-$abon_item,2,".",",");  ?></p>
                            
<?php

 


 $con->desconectar();                                         