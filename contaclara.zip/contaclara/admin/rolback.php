<?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
  

  $crud->update("update cotizacion set estado = 'COTIZADO' where id = '$_POST[refe]'","Pedido reversado con exito.",$con->getConection());



 $con->desconectar();


?>



