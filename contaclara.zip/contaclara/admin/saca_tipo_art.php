 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>
<option value="0" selected= "selected">Escoja tipo de artículo</option>




                                            <?php
                                             $crud->setConsulta("SELECT id,nombre from tipo_art order by nombre asc");
                                             $datos1 = $crud->seleccionar($con->getConection());
                                             $i=0;
                                             while ($i<sizeof($datos1))
                                             {   
                                            ?>
                                          <option value="<?php echo $datos1[$i]['id'] ?>"><?php echo $datos1[$i]['nombre'] ?></option>  
                  
  <?php
    $i++;
   }
  ?>



<?php
 $con->desconectar();


?>
                                    