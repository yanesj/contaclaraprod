 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>


                                         <tbody>
                                             <tr>
                                               <th class="text-center">DESCRIPCIÓN</th>
                                               <th class="text-center">ADEUDADO: $</th>
                                               <th class="text-center">MONTO A ABONAR: $</th>
                                             </tr>
                                      <?php
                                             $crud->setConsulta("SELECT precio_web,flete,direccion,provincia,distrito,telefono1,telefono2,email,cip_ruc,cotizacion,smi,nombre,apellido,item_id,con_ab_it,total_cotizacion,abonado,
(tot_precio_item) AS tot_precio_item,descripcion,(total_abonado_item) AS total_abonado_item,(flete_smi * 0.07) AS flete_smi,porcentaje_ab  FROM saldos


WHERE cotizacion = '$_GET[uid]' ");
                                             $datos1 = $crud->seleccionar($con->getConection());
                                             $i=0;
                                             while ($i<sizeof($datos1))
                                             {   
                                                $item = $datos1[$i]['item_id'];  
                                                 
                                              
                                                           //hacer las comparaciones de los fletes
                                                            $crud_compara = new Crud();
                                                            $crud_compara->setConsulta(" SELECT segundo_flete,
  (precio_web+flete_smi+flete_smi*0.07) AS p_flete,(precio_web+COALESCE(`segundo_flete`,0)+COALESCE(`segundo_flete`,0)*0.07) AS s_flete
   FROM items WHERE items.`id` = $item ");
                                                            $datos_compara = $crud_compara->seleccionar($con->getConection());
                                                            $i1=0;$difer =0;
                                                            while($i1 < sizeof($datos_compara))
                                                            {
                                                                if($datos_compara[$i1]['segundo_flete'] != 0)
                                                                { 
                                                                  $difer = $difer + ($datos_compara[$i1]['s_flete'] - $datos_compara[$i1]['p_flete']);
                                                                }
                                                                 $i1++;
                                                            }
                                                           //fin hacer las comparaciones de los fletes



                                                  //se hará la diferencia de los fletes, y se aplicará en este módulo, en el pdf, y en la factura


                                                 $tot_art = ($datos1[$i]['precio_web']+$datos1[$i]['flete']+$datos1[$i]['flete']*0.07);
                                                 
                                                 $c_abon_ini = $tot_art * $datos1[$i]['porcentaje_ab']/100 ;
                                                 $abon_secu =  $datos1[$i]['total_abonado_item'];

                                                 $sal_pend =  $c_abon_ini - $abon_secu; 
                                                 //pendiente, articulos en su abono inicial y secundario
                                            ?>     

                                            <tr>
                                               <td><input id="item<?php echo $i ?>" class="form-control" type="hidden" placeholder="Telefono 1" name="item<?php echo $i ?>" value="<?php echo $datos1[$i]['item_id'] ?>"><?php echo $datos1[$i]['descripcion'] ?></td>
                                               <td align="right"><?php echo  number_format($tot_art-$c_abon_ini- $abon_secu + $difer ,2,".",",") ?></td>
                                               <td><input id="abo<?php echo $i ?>" class="form-control text-right y33" type="text"   onKeyPress='return validarnum(event)' onfocusout="alert(fde);" placeholder="Cantidad USD" value="0.00" name="abo<?php echo $i ?>" ></td>
                                             </tr>
                                             <?php
    $i++;
   }
  ?>
<?php
 $con->desconectar();
?>

                                           </tbody>
                                   

<script type="text/javascript">
                $(function() {
      // Format while typing & warn on decimals entered, no cents
      $(".y33").blur(function() {
        $('#formatWhileTypingAndWarnOnDecimalsEnteredNotification').html(null);
        $(this).formatCurrency({ colorize: true, negativeFormat: '-%s%n', roundToDecimalPlace: 2 });
      })
      .keyup(function(e) {
        var e = window.event || e;
        var keyUnicode = e.charCode || e.keyCode;
        if (e !== undefined) {
          switch (keyUnicode) {
            case 16: break; // Shift
            case 27: this.value = ''; break; // Esc: clear entry
            case 35: break; // End
            case 36: break; // Home
            case 37: break; // cursor left
            case 38: break; // cursor up
            case 39: break; // cursor right
            case 40: break; // cursor down
            case 78: break; // N (Opera 9.63+ maps the "." from the number key section to the "N" key too!) (See: http://unixpapa.com/js/key.html search for ". Del")
            case 110: break; // . number block (Opera 9.63+ maps the "." from the number block to the "N" key (78) !!!)
            case 190: break; // .
            default: $(this).formatCurrency({ colorize: true, negativeFormat: '-%s%n', roundToDecimalPlace: -1, eventOnDecimalsEntered: true });
          }
        }
      })
      .bind('decimalsEntered', function(e, cents) {
        var errorMsg = 'Please do not enter any cents (0.' + cents + ')';
        $('#formatWhileTypingAndWarnOnDecimalsEnteredNotification').html(errorMsg);
        log('Event on decimals entered: ' + errorMsg);
      });


      

    });
  </script>