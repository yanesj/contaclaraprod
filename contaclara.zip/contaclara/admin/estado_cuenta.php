 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>


 <table id="cuentas" class="display">
                                          <thead>
                                            <tr>
                                              <th>FECHA</th>
                                       
                                              <th>REF</th>
                                       
                                              <th>TOTAL FACTURA</th>
                                              <th>ABONADO</th>
                                              <th>DIFERENCIA</th>
                                              
                                            </tr>
                                          </thead>
                                          <tbody id="cuerpo">
                                         
                                               <?php
                                             $crud->setConsulta("SELECT fecha_pedido,direccion,provincia,distrito,telefono1,telefono2,email,cip_ruc,cotizacion as id,smi,nombre,apellido,item_id,con_ab_it,total_cotizacion,abonado,
SUM(tot_precio_item) AS tot_precio_item,descripcion,SUM(total_abonado_item) AS total_abonado_item,SUM(flete_smi * 0.07) AS flete_smi,porcentaje_ab  FROM saldos


WHERE smi = '$_GET[uid]' GROUP BY cotizacion ");
                                             $datos1 = $crud->seleccionar($con->getConection());
                                             $i=0;
                                             while ($i<sizeof($datos1))
                                             {   
                                                 $date = date_create($datos1[$i]['fecha_pedido']);

                                                 $devengo=$datos1[$i]['total_cotizacion'];
                                                 $deduc=  $datos1[$i]['abonado']+$datos1[$i]['total_abonado_item']; 
                                            ?>

                                                                  <tr>
                                                                     <td><?php  echo date_format($date, 'd-m-Y');  ?></td>
                                                                    <td><?php echo $datos1[$i]['id'] ?></td>
                                                                    <td align="right"><?php echo '$'. number_format($datos1[$i]['total_cotizacion'],2,".",",") ?></td>
                                                                    <td align="right"><?php echo '$'.number_format($deduc,2,".",",") ?></td>
                                                                     <td align="right"><?php echo '$'.number_format($devengo-$deduc,2,".",",") ?></td>
                                                                
                                                                  
                                                                  
                                                                  </tr>

                                           <?php
                                               $i++;
                                            }
                                           ?>                       
                                     </tbody>
                                        </table> 
<?php
 $con->desconectar();
?>