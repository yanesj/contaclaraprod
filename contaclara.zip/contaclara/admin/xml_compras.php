<?php
   include('../_include/configuration.php');
  $connection=mysql_connect($server,$user,$password);
  mysql_select_db($dbname);
   mysql_query("SET NAMES 'utf8'");

$query = "SELECT peso_r,peso,direccion,provincia,distrito,telefono1,telefono2,email,cip_ruc,cotizacion AS referencia,smi,nombre,apellido,item_id,
  con_ab_it,total_cotizacion,abonado,
  (tot_precio_item) AS tot_precio_item,descripcion,(total_abonado_item) AS total_abonado_item,
  (flete_smi * 0.07) AS flete_smi,porcentaje_ab,estado_cot,item_estado,suc_nombre,tipo_servicio, tipo_articulo,precio_web,item_descrip 
  ,flete,  CASE procedencia WHEN '1' THEN 'América'
   WHEN '2' THEN 'Asia' WHEN '3' THEN 'Europa'
   WHEN '4' THEN 'Oceania'    
      END AS procedencia,fecha_pedido,weblink
   FROM saldos WHERE item_id = '$_GET[uid]'
";
$result = mysql_query($query,$connection);
$row = mysql_fetch_array($result);
$flete = $row['flete'];

$total = $row['precio_web'] + $row['flete'] + $row['flete'] *0.07; 


/*abono*/
$abono = ($total * $row['porcentaje_ab']/100) + $row['total_abonado_item'] ;
/*fin abono*/


//hacer las comparaciones de los fletes
                                                            
                                              $query_comp=" SELECT segundo_flete,
  (precio_web+flete_smi+flete_smi*0.07) AS p_flete,(precio_web+COALESCE(`segundo_flete`,0)+COALESCE(`segundo_flete`,0)*0.07) AS s_flete,cantidad
   FROM items WHERE items.`id` = $_GET[uid] ";

                                              $result= mysql_query($query_comp,$connection);   
                                              if($result)
                                              {
                                                  $difer =0;
                                                  $canti = 0;
                                                   while($row_comp = mysql_fetch_array($result))
                                                            {
                                                                $canti = $row_comp['cantidad'];

                                                                if($row_comp['segundo_flete'] != 0)
                                                                { 
                                                                  $difer = $difer + ($row_comp['s_flete'] - $row_comp['p_flete']);
                                                                  $flete = $row_comp['segundo_flete'];
                                                                 
                                                                }
                                                               
                                                                 
                                                            }
                                              }
                                              else
                                              {
                                                echo mysql_error();
                                              }
                                                           
                                                           //fin hacer las comparaciones de los fletes


  
$total = $row['precio_web']+$row['flete'] + ($row['flete']* 0.07);



header("Content-Type: text/html;charset=utf-8");
echo '<?xml version="1.0" encoding="UTF8"?>
<user>
<sucursal>'.$row['suc_nombre'].'</sucursal>
<tipo_servicio>'.$row['tipo_servicio'].'</tipo_servicio>
<fecha_pedido>'.$row['fecha_pedido'].'</fecha_pedido>
<cliente>'.'SMI-'.$row['smi'].' '.$row['nombre'].' '.$row['apellido'].'</cliente>

<descripcion>'.$row['descripcion'].'</descripcion>
<weblink>'.$row['weblink'].'</weblink>
<precio_web>'.$row['precio_web'].'</precio_web>
<flete_smi>'.$flete.'</flete_smi>
<total>'.number_format($total,2,'.',',').'</total>
<item>'.$row['item_id'].'</item>
<abono>'.number_format($abono ,2,'.',',').'</abono>
<resto>'.number_format(($total-$abono+$difer),2,'.',',').'</resto>
<referencia>'.$row['referencia'].'</referencia>
<peso>'.$row['peso'].'</peso>
<peso_r>'.$row['peso_r'].'</peso_r>
<cantidad>'.$canti.'</cantidad>

</user>';
mysql_close($connection);
?>