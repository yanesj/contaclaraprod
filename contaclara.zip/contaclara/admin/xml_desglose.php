<?php
   include('../_include/configuration.php');
  $connection=mysql_connect($server,$user,$password);
  mysql_select_db($dbname);
   mysql_query("SET NAMES 'utf8'");

$query = "SELECT items.id, descripcion,cliente.`nombre`,cliente.`apellido`,cliente.id as cli_id FROM items 
JOIN cotizacion ON (cotizacion.id = items.`cotizacion_id`) 
JOIN cliente  ON (cliente.id = cotizacion.`cliente_id`)
WHERE cotizacion.id = '$_GET[uid]'
 ORDER BY items.id ASC";
$result = mysql_query($query,$connection);
$row = mysql_fetch_array($result);



$pieces = explode("-",$row['fecha_nacimiento']); 
$fn = $pieces[1].'/'.$pieces[2].'/'.$pieces[0];

mysql_close($connection);

header("Content-Type: text/html;charset=utf-8");
echo '<?xml version="1.0" encoding="UTF8"?>
<user>
<id>'.$row['id'].'</id>
<cli_id>'.$row['cli_id'].'</cli_id>
<nombre>'.$row['nombre'].'</nombre>
<apellido>'.$row['apellido'].'</apellido>

</user>';
?>