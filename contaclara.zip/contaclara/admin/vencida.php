 <?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>


<?php
 $crud->setConsulta("SELECT DATE_ADD(fecha_creacion, INTERVAL 3 DAY) AS adelanto FROM cotizacion WHERE id='$_GET[uid]'");
 $datos1 = $crud->seleccionar($con->getConection());
    $date1 = new DateTime($datos1[0]['adelanto']);
    $date2 = new DateTime("now"); 
 

 
    if($date2<=$date1)
    {
      ?>
       <small id="anuncio" class="label bg-blue">Cotización vigente</small>    
      <?php
    }
    else
    {
         ?>
               <small id="anuncio" class="label bg-red">Cotización vencida</small>

         <?php
    }
                               

    
 
  ?>


<?php
 $con->desconectar();


?>
       