<?php
include('../_include/configuration.php');
$connection=mysql_connect($server,$user,$password);
  mysql_select_db($dbname);
   mysql_query("SET NAMES 'utf8'");

$query = "SELECT * FROM cliente where cedunit= '$_GET[ocul]'";
$result = mysql_query($query,$connection);
$row = mysql_fetch_array($result);

$query2="SELECT retencion_id,valor  FROM cliente_retencion WHERE cliente_id = '$_GET[ocul]' order by retencion_id";
$result2 = mysql_query($query2,$connection);
 $i=1;  
 while($row2 = mysql_fetch_array($result2))
 {
     
 	$cadena = $cadena.'<ret'.$i.'>'.$row2['valor'].'</ret'.$i.'>';

 	$i++;
 }
mysql_close($connection);
header("Content-Type: text/html;charset=utf-8");
echo '<?xml version="1.0" encoding="UTF8"?>
<user>
<cedunit>'.$row['cedunit'].'</cedunit>
<concepto>'.$row['concepto'].'</concepto>
<tipodoc>'.$row['tipodoc'].'</tipodoc>
<dv>'.$row['dv'].'</dv>
<papel>'.$row['papel'].'</papel>
<sapel>'.$row['sapel'].'</sapel>
<pnombre>'.$row['pnombre'].'</pnombre>
<snombre>'.$row['snombre'].'</snombre>
<rsocial>'.$row['rsocial'].'</rsocial>
<direccion>'.$row['direccion'].'</direccion>
<coddepart>'.$row['coddepart'].'</coddepart>
<codmun>'.$row['codmun'].'</codmun>
<codpais>'.$row['codpais'].'</codpais>
<gcontri>'.$row['gcontri'].'</gcontri>
<calidadcontri>'.$row['calidadcontri'].'</calidadcontri>
<notaevalcontri>'.$row['notaevalcontri'].'</notaevalcontri>'.
 $cadena.'
</user>';
?>