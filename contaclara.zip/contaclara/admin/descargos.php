 <?php
session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>











 <table class="table table-bordered table-striped table-condensed" id="table_id">
                                       <thead>
                                          <tr>
                                             <th>REF.</th>
                                             <th>SUCURSAL</th>
                                            
                                             <th>SERVICIO</th>
                                             <th>CANT.</th>
                                             
                                             <th>FECHA PEDIDO</th>
                                             <th>CLIENTE</th>
                                             <th>DESCRIPCION</th>
                                             <th>PRECIO WEB</th>
                                             <th>FLETE SMI</th>
                                             <th>TOTAL + ITMBS</th>
                                             <th>ABONO</th>
                                             <th>SALDO</th>
                                             <th>ESTADO</th>
                                        
                                          </tr>   
                                       </thead>
                                
                                       <tbody>
                           
                                       <?php
                                         $crud->setConsulta("SELECT cantidad,cotizacion,smi,item_id,suc_nombre,smi
,nombre,apellido,tipo_servicio,descripcion,fecha_pedido,precio_web,flete_smi,abonado,total_abonado_item,
                                          estado_item,segundo_flete,porcentaje_ab
                                           FROM saldos
  WHERE pedido_por = '$_SESSION[id]' AND estado_item = 'EN TRANSITO' OR  estado_item = 'EN ALMACEN'  ");
                     $datos1 = $crud->seleccionar($con->getConection());
                       $i=0;
                       $date = date_create($datos1[$i]['fecha_pedido']);
                       while ($i<sizeof($datos1))
                       {                        
                                       
                             $abonado = $datos1[$i]['precio_web'] + $datos1[$i]['flete_smi'] + $datos1[$i]['flete_smi'] * 0.07;

                             $abonado = $abonado * $datos1[$i]['porcentaje_ab']/100; 

                             if($datos1[$i]['segundo_flete']==0)
                             {
                               $flete = $datos1[$i]['flete_smi'];
                             }
                             else
                             {
                                $flete = $datos1[$i]['segundo_flete'];
                             }

                            //  $abono = $datos1[$i]['total'] * $datos1[$i]['porcentaje_ab'] / 100;
                                             $tot_fact =number_format(($datos1[$i]['precio_web']+$flete+$flete*0.07),2,'.',',' ); 
                                             $abono_fact =number_format($abonado+$datos1[$i]['total_abonado_item'],2,'.',','); 

                                       ?>
                                        <tr>
                                          <td><a style="cursor:pointer" onclick="<?php if( (abs($abono_fact - $tot_fact))<= 0.01 &&  $datos1[$i]['segundo_flete']!=0 && $datos1[$i]['estado_item'] =='EN ALMACEN' ){?>javascript:entregar_art(<?php echo $datos1[$i]['item_id']?>)<?php }else{echo 'javascript:modal_ap('.$datos1[$i]['item_id'].')';}?>"><?php echo $datos1[$i]['cotizacion'] ?></a> </td>
                                         <td><!-- <a style="cursor:pointer" data-target="#itmesadd" data-toggle="modal" data-param="<?php echo $datos1[$i]['item']  ?>"><?php echo $datos1[$i]['sucursal'] ?></a> -->
                                                    <?php echo $datos1[$i]['suc_nombre'] ?>
                                         </td>
                                       
                                         <td><?php echo $datos1[$i]['tipo_servicio'] ?> </td>
                                         <td><?php echo $datos1[$i]['cantidad'] ?> </td>
                                         <td><?php echo date_format($date, 'd-m-Y') ?> </td>

                                         
                                         <td><?php echo 'SMI-'.$datos1[$i]['smi'].' '.$datos1[$i]['nombre'].' '.$datos1[$i]['apellido'] ?> </td>
                                         <td align="left"><?php echo $datos1[$i]['descripcion']?> </td>
                                         <td align="right"><?php echo '$'.number_format($datos1[$i]['precio_web'],2,'.',',') ?> </td>
                                         <td align="right"><?php  echo '$'.number_format($flete,2,'.',',') ?> </td>
                                         <td align="right"><?php  echo '$'.number_format(  ($datos1[$i]['precio_web']+$flete+$flete*0.07),2,'.',',') ?> </td>
                                         <td align="right"><?php  echo '$'.number_format($abonado+$datos1[$i]['total_abonado_item'] ,2,'.',',') ?> </td>
                                        
                                         <?php
                                           $saldo = ($datos1[$i]['precio_web']+$flete+$flete*0.07) - ($abonado+$datos1[$i]['total_abonado_item']); 
                                         ?> 



                                         <td align="right"><?php  echo '$'.number_format($saldo ,2,'.',',') ?> </td>  

                                            <td align="left"><?php echo $datos1[$i]['estado_item']?> </td>
                                        </tr> 
                      <?php
                            $i++;
                        }
                     ?>

                                       </tbody>
                                    </table>  