<?php
	$connection = mysql_connect('localhost','root','');
	mysql_select_db('smi');
	$query = "select * from items";
	$result=mysql_query($query,$connection);
	while($row = mysql_fetch_array($result))
	{
       echo $row['tipo_servicio'];
	}

?>



