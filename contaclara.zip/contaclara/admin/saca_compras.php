<?php
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();
?>


 <table class="table table-bordered table-striped table-condensed" id="table_id">
                                       <thead>
                                          <tr>
                                             <th>REF.</th>
                                             <th>SUCURSAL</th>
                                            
                                             <th>SERVICIO</th>
                                             <th>TIP ART.</th>
                                             <th>CANT.</th>
                                             

                                             <th>PROC.</th>
                                             <th>FECHA PEDIDO</th>
                                             <th>CLIENTE</th>
                                             <th>DESCRIPCION</th>
                                                 <th>TOTAL</th>
                                             <th>ABONO</th>
                                             <th>PRECIO WEB</th>
                                             <th>FLETE</th>
                                         
                                        
                                          </tr>   
                                       </thead>
                                
                                       <tbody>
                           
                                       <?php
                                         $crud->setConsulta(" SELECT direccion,provincia,distrito,telefono1,telefono2,email,cip_ruc,cotizacion AS referencia,smi,nombre,apellido,item_id,
  con_ab_it,total_cotizacion,abonado,cantidad,
  (tot_precio_item) AS tot_precio_item,descripcion,(total_abonado_item) AS total_abonado_item,
  (flete_smi * 0.07) AS flete_smi,porcentaje_ab,estado_cot,item_estado,suc_nombre,tipo_servicio, tipo_articulo,precio_web,item_descrip 
  ,flete,  CASE procedencia WHEN '1' THEN 'América'
   WHEN '2' THEN 'Asia' WHEN '3' THEN 'Europa'
   WHEN '4' THEN 'Oceania'    
      END AS procedencia,fecha_pedido,primer_abono
   FROM saldos  WHERE estado_cot ='PEDIDO' AND estado_item IS NULL
  GROUP BY item_id");
                     $datos1 = $crud->seleccionar($con->getConection());
                       $i=0;
                       while ($i<sizeof($datos1))
                       {                        
                                       
                            //  $abono = ($datos1[$i]['total'] + ($datos1[$i]['flete_smi'] * 0.07)) * $datos1[$i]['porcentaje_ab'] / 100;

                              $date = date_create($datos1[$i]['fecha_pedido']);

                                       ?>
                                        <tr>
                                          <td><a style="cursor:pointer" onclick="javascript:modal_ap(<?php echo $datos1[$i]['item_id']  ?>)"><?php echo $datos1[$i]['referencia'] ?></a> </td>
                                         <td><!-- <a style="cursor:pointer" data-target="#itmesadd" data-toggle="modal" data-param="<?php echo $datos1[$i]['item']  ?>"><?php echo $datos1[$i]['sucursal'] ?></a> -->
                                                    <?php echo $datos1[$i]['suc_nombre'] ?>
                                         </td>
                                       
                                         <td><?php echo $datos1[$i]['tipo_servicio'] ?> </td>
                                         <td><?php echo $datos1[$i]['tipo_articulo'] ?> </td>
                                             <td><?php echo $datos1[$i]['cantidad'] ?> </td>
                                         <td><?php echo  $datos1[$i]['procedencia'] ?> </td>

                                         <td><?php echo date_format($date, 'd-m-Y'); ?> </td>
                                         <td><?php echo 'SMI-'.$datos1[$i]['smi'].' '.$datos1[$i]['nombre'].' '.$datos1[$i]['apellido'] ?> </td>
                                         <td align="left"><?php echo $datos1[$i]['descripcion']?> </td>
                                           <td  align="right"><span style="font-weight:bold; color: red"><?php echo '$'.number_format(($datos1[$i]['tot_precio_item']),2,'.',',') ?> </span> </td>
                                         <td align="right"><span style="font-weight:bold; color: green"><?php echo '$'. number_format(($datos1[$i]['primer_abono']+$datos1[$i]['total_abonado_item']),2,'.',',') ?></span/> </td>
                               
                                         <td  align="right"><span style="font-weight:bold; color: orange"><?php echo '$'.number_format($datos1[$i]['precio_web'],2,'.',',') ?></span> </td>
                                         <td  align="right"><span style="font-weight:bold; color: blue"><?php echo '$'.number_format($datos1[$i]['flete'],2,'.',',') ?></span> </td>
                                       
                                        </tr> 
                      <?php
                            $i++;
                        }
                     ?>

                                       </tbody>
                                    </table>  