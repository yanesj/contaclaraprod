<?php
 session_start();
 include('../_include/configuration.php');
  include('../_classes/conectar.php');
  include('../_classes/crud.php');

 $con = new Coneccion($server,$user,$password,$dbname);
  $con->conectar();
  $crud = new Crud();


  $fecha = date('Y-m-d');
  
  $fnaci = explode("/", $_POST['f_nac']);

  $f_entra = $fnaci[2]."/".$fnaci[1]."/".$fnaci[0];

	
  $crud->moneda_dec($_POST['quoted']);
  $_POST['quoted'] = $crud->getValor(); 


  $crud->moneda_dec($_POST['money']);
  $_POST['money'] = $crud->getValor(); 
  $crud->moneda_dec($_POST['us_price']);
  $_POST['us_price'] = $crud->getValor();
  $crud->moneda_dec($_POST['money']);
  $_POST['money'] = $crud->getValor();
    $crud->moneda_dec($_POST['shipping']);
  $_POST['shipping'] = $crud->getValor();
  $crud->moneda_dec($_POST['total_us']);
  $_POST['total_us'] = $crud->getValor();
   $crud->moneda_dec($_POST['ptyship']);
  $_POST['ptyship'] = $crud->getValor();
   $crud->moneda_dec($_POST['estimate_total']);
  $_POST['estimate_total'] = $crud->getValor();
     $crud->moneda_dec($_POST['realpty']);
  $_POST['realpty'] = $crud->getValor();

     $crud->moneda_dec($_POST['realptp']);
  $_POST['realptp'] = $crud->getValor();
      $crud->moneda_dec($_POST['estim_rev']);
  $_POST['estim_rev'] = $crud->getValor();
        $crud->moneda_dec($_POST['r_r']);
  $_POST['r_r'] = $crud->getValor();
        $crud->moneda_dec($_POST['r_rp']);
  $_POST['r_rp'] = $crud->getValor();

  



  

 


  







   if($_POST['idocul']=='')
	 { 
	    $array[0] = "'$_POST[order]','$_POST[items_volc]','$_POST[id_cli]','$_POST[quoted]','$_POST[money]','$_POST[us_price]','$_POST[shipping]','$_POST[total_us]','$_POST[ptyship]','$_POST[estimate_total]','$_POST[carrier]','$_POST[realpty]','$_POST[realptp]','$_POST[estim_rev]','$_POST[estim_revp]','$_POST[r_r]','$_POST[r_rp]'";
		  $campos = "orden,item,cliente,quoted_item,money_recived,us_price,shipping,total_us,estim_pt_ship,estim_pt_fl,carrier,realpts,realptp,estimrev,estimrevp,realrevenue,realrevenuep";
		  $tabla = "revenue";
		  $mensaje = "Registro Guardado con exito.";
		  $crud->insertar($array,$campos,$tabla,$con->getConection(),$mensaje); 
     }
    else
    {
         

         $crud->update("update cliente set cip_ruc = '$_POST[cip_ruc]',nombre = '$_POST[nombre]',apellido = '$_POST[apellido]',direccion = '$_POST[direccion]',provincia = '$_POST[provincia]',distrito = '$_POST[distrito2]',telefono1 = '$_POST[telefono1]',telefono2 = '$_POST[telefono2]',email = '$_POST[email]',fecha_nacimiento = '$f_entra', comentarios = '$_POST[comentarios]' where id = '$_POST[idocul]'",'Cliente actualizado exitosamente.',$con->getConection());  
    } 


 $con->desconectar();


?>

