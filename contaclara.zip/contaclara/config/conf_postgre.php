<?php
$user = "postgres";
$password = "1234";
$dbname = "imagenes";
$port = "5432";
$server = "localhost";



?>