
<section class="sidebar">
  <!-- Sidebar user panel -->
  <div class="user-panel">
    <div class="pull-left image">
      <img src="../images/avatar.png" class="img-circle" alt="User Image" />
    </div>
    <div class="pull-left info">
      

      <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
    </div>
  </div>
  <div class="user-panel">

    <div class="pull-left info">
      <p></p>


    </div>
  </div>

                      <ul class="sidebar-menu">
                                                <li>
                          <a href="../views/dashboard.php">
                                <i  class="fa fa-dashboard"></i> <span>dashboard</span>
                            
                          </a>
                        </li>
                        <li>
                          <a href="../views/crear_emp.php">
                                <i  class="fa fa-plus"></i> <span>Crear Empresa</span>
                            
                          </a>
                        </li>
                        

                        <li>
                          <a href="../views/crear_usu.php">
                                <i class="fa fa-plus"></i> <span>Crear Usuario</span>
                          
                          </a>
                        </li>
                        
                           <li>
                            <a href="../views/consult_emp.php">
                                <i class="fa fa-list-ul"></i> <span>Consultar Empresas</span>
                            </a>
                        </li>
</ul>
</section>