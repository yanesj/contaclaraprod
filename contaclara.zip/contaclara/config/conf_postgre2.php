<?php
$user2 = "postgres";
$password2 = "1234";
$dbname2 = "emp_1234";
$port2 = "5432";
$server2 = "localhost";



?>