 <!--<div align="center">
 <div class="row">
  <div class="col-sm-2" style="background-color:gray;">.columna 1</div>
  <div class="col-sm-2" style="background-color:gray;">.columna 2</div>
  <div class="col-sm-2" style="background-color:gray;">.columna 3</div>
  <div class="col-sm-2" style="background-color:gray;">.columna 4</div>
</div>
<div> -->
    <!-- Small boxes (Stat box) -->
                   <div class="row" style="margin:10px auto">
                        <div class="col-lg-2 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-aqua">
                                <div class="inner">
                                    <a href="../views/crear_emp.php">
                                        <font color ="white"> <h4>Crear Empresa</h4>
                                            <div class="icon">
                                    <img src="../images/icons/varios1.png">

                                </div></font>
                                    </a>
                                </div>
                               <a href="../index.php" class="small-box-footer">
                                    Más información <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        <div class="col-lg-2 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-green">
                                <div class="inner">
                                   <a href="../views/crear_usu.php">
                                        <font color ="white"><h4>Crear Usuario</font></h4>
                                    </a>
                                </div>
                                <div class="icon">
                                    <img src="../images/icons/individual2.png">
                                </div>
                               <a href="index.php" class="small-box-footer">
                                    Más información <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                        <div class="col-lg-2 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-yellow">
                                <div class="inner">
                                    <a href="../views/consult_emp.php">
                                        <font color ="white"><h4>Consultar Empresas</font></h4>
                                    </a>
                                </div>
                                <div class="icon">
                                    <img src="../images/icons/par2.png">
                                </div>
                                <a href="index.php" class="small-box-footer">
                                    Más información <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>

                        <!-- ./col -->
                       <div class="col-lg-2 col-xs-6">
                          
                            <div class="small-box bg-red">
                                <div class="inner">
                                    <p>
                                       <h4>Campo 4</h4>
                                    </p>
                                </div>
                                <div class="icon">
                                    <img src="../images/icons/agregar1.png">
                                </div>
                                <a href="index.php" class="small-box-footer">         
                                  Más información <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div> 
                         <div class="col-lg-2 col-xs-6">
                            
                            <div class="small-box bg-red">
                                <div class="inner">
                                    <p>
                                       <h4>Campo 5</h4>
                                    </p>
                                </div>
                                <div class="icon">
                                    <img src="../images/icons/agregar1.png">
                                </div>
                                <a href="index.php" class="small-box-footer">         
                                  Más información <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                        
                    </div>
                    